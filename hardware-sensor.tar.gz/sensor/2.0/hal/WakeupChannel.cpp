/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <errno.h>
#include <unistd.h>
#include <log/log.h>
#include <string.h>
#include <inttypes.h>

#include "WakeupChannel.h"

#undef LOG_TAG
#define LOG_TAG "WakeupChannel"

static int32_t wakeUpToNonWakeUp(int32_t wakeUp) {
    int32_t nonWakeUp = -1;

    switch (wakeUp) {
    case SENSOR_TYPE_STEP_DETECTOR_WAKEUP:
        nonWakeUp = SENSOR_TYPE_STEP_DETECTOR;
        break;
    default:
        nonWakeUp = -1;
        break;
    }
    return nonWakeUp;
}

static int32_t nonWakeUpToWakeUp(int32_t nonWakeUp) {
    int32_t wakeUp = -1;

    switch (nonWakeUp) {
    case SENSOR_TYPE_STEP_DETECTOR:
        wakeUp = SENSOR_TYPE_STEP_DETECTOR_WAKEUP;
        break;
    default:
        wakeUp = -1;
        break;
    }
    return wakeUp;
}

WakeupChannel::WakeupChannel() {
    int pipeFds[2] = {-1};

    mWritePipeFd = -1;
    mReadPipeFd = -1;

    mSensorManager = SensorManager::getInstance();
    mSensorConnection = mSensorManager->createSensorConnection(WAKEUP_CHANNEL);

    if (pipe(pipeFds) < 0)
        ALOGE("error creating pipe (%s)\n", strerror(errno));
    if (fcntl(pipeFds[0], F_SETFL, O_NONBLOCK) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    if (fcntl(pipeFds[1], F_SETFL, O_NONBLOCK) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    if (fcntl(pipeFds[0], F_SETPIPE_SZ, 256*1024) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    mWritePipeFd = pipeFds[1];
    mReadPipeFd = pipeFds[0];

    mHfLooper.reset(new HfLooper(getFd(), 128, false));
}

WakeupChannel::~WakeupChannel() {
    mSensorManager->removeSensorConnection(mSensorConnection);
    mSensorManager = NULL;
    mHfLooper.reset();
}

int WakeupChannel::getFd() {
    return mReadPipeFd;
}

int WakeupChannel::reportFlush(int handle) {
    struct hf_manager_event event;

    memset(&event, 0, sizeof(struct hf_manager_event));
    event.sensor_type = handle;
    event.action = FLUSH_ACTION;
    if (write(mWritePipeFd, &event, sizeof(struct hf_manager_event)) < 0)
        ALOGE("write event to mWriteFd failed\n");
    return 0;
}

int WakeupChannel::reportData(int handle, const sensors_event_t *data) {
    struct hf_manager_event event;

    memset(&event, 0, sizeof(struct hf_manager_event));
    event.sensor_type = handle;
    event.timestamp = data->timestamp;
    event.action = DATA_ACTION;

    if (handle == SENSOR_TYPE_STEP_DETECTOR_WAKEUP) {
        event.word[0] = (int32_t)data->data[0];
    }

    if (write(mWritePipeFd, &event, sizeof(struct hf_manager_event)) < 0)
        ALOGE("write event to mWriteFd failed\n");
    return 0;
}

int WakeupChannel::enable(int32_t handle, int en) {
    int32_t nonWakeUpHandle = -1;

    ALOGI("enable: [%d,%d]\n", handle, en);

    nonWakeUpHandle = wakeUpToNonWakeUp(handle);
    if (nonWakeUpHandle < 0)
        return -1;

    return mSensorManager->activate(mSensorConnection, nonWakeUpHandle, en);
}

int WakeupChannel::batch(int handle, int flags,
        int64_t samplingPeriodNs, int64_t maxBatchReportLatencyNs) {
    int32_t nonWakeUpHandle = -1;

    ALOGI("batch: [%d,%d,%" PRId64 ",%" PRId64 "]\n",
        handle, flags,samplingPeriodNs, maxBatchReportLatencyNs);

    nonWakeUpHandle = wakeUpToNonWakeUp(handle);
    if (nonWakeUpHandle < 0)
        return -1;

    return mSensorManager->batch(mSensorConnection, nonWakeUpHandle,
        samplingPeriodNs, maxBatchReportLatencyNs);
}

int WakeupChannel::flush(int handle) {
    reportFlush(handle);
    return 0;
}

int WakeupChannel::setEvent(const sensors_event_t *data) {
    int32_t wakeUpHandle = -1;

    /* ALOGD("setEvent handle=%d x=%f, y=%f, z=%f, timestamp=%lld\n",
        data->sensor, data->data[0], data->data[1], data->data[2], data->timestamp); */

    if ((wakeUpHandle = nonWakeUpToWakeUp(data->sensor)) < 0) {
        ALOGI("setEvent: wrong event handle=%d\n", data->sensor);
        return 0;
    }
    reportData(wakeUpHandle, data);
    return 0;
}

int WakeupChannel::readEvents(sensors_event_t* data, int count) {
    return mHfLooper->eventRead(data, count);
}
