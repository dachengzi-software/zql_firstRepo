/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <errno.h>
#include <unistd.h>
#include <log/log.h>
#include <string.h>
#include <inttypes.h>

#include "hwmsen_custom.h"
#include "OriginChannel.h"

#undef LOG_TAG
#define LOG_TAG "OriginChannel"

OriginChannel::OriginChannel() {
    mHfManager.reset(new HfManager());
    mHfLooper.reset(new HfLooper(mHfManager->getFd(), 128));
    memset(ts_reverse_debug, 0, sizeof(ts_reverse_debug));
#ifndef MAG_CALIBRATION_IN_SENSORHUB
    mSensorCalibration = SensorCalibration::getInstance();
    mSensorCalibration->magInitCalibration();
#endif
}

OriginChannel::~OriginChannel() {
    mHfManager.reset();
    mHfLooper.reset();
#ifndef MAG_CALIBRATION_IN_SENSORHUB
    mSensorCalibration = NULL;
#endif
}

int OriginChannel::getFd() {
    return mHfManager->getFd();
}

int OriginChannel::enable(int sensor_handle, int enabled) {
    ALOGI("activate: [%d,%d]", sensor_handle, enabled);
#ifndef MAG_CALIBRATION_IN_SENSORHUB
    if (sensor_handle == SENSOR_TYPE_MAGNETIC_FIELD)
        mSensorCalibration->magEnableCalibration(enabled);
#endif
    return mHfManager->activateSensor(sensor_handle, enabled);
}

int OriginChannel::batch(int sensor_handle, int /* flags */,
        int64_t sampling_period_ns, int64_t max_report_latency_ns) {
    ALOGI("batch: [%d,%" PRId64 ",%" PRId64 "]", sensor_handle,
        sampling_period_ns, max_report_latency_ns);
    return mHfManager->batchSensor(sensor_handle,
        sampling_period_ns, max_report_latency_ns);
}

int OriginChannel::flush(int sensor_handle) {
    ALOGI("flush: [%d]", sensor_handle);
    return mHfManager->flushSensor(sensor_handle);
}

void OriginChannel::processMagCalibration(sensors_event_t* data) {
#ifndef MAG_CALIBRATION_IN_SENSORHUB
    struct sensorData inputData;
    struct sensorData outputData;

    memset(&inputData, 0, sizeof(struct sensorData));
    memset(&outputData, 0, sizeof(struct sensorData));

    inputData.data[0] = data->magnetic.x;
    inputData.data[1] = data->magnetic.y;
    inputData.data[2] = data->magnetic.z;
    inputData.status = data->magnetic.status;
    inputData.timeStamp = data->timestamp;
    mSensorCalibration->magRunCalibration(&inputData, &outputData);
    data->magnetic.x = outputData.data[0];
    data->magnetic.y = outputData.data[1];
    data->magnetic.z = outputData.data[2];
    data->magnetic.status = outputData.status;
    mSensorCalibration->magGetCalibration(&outputData);
    data->data[13] = outputData.data[0];
    data->data[14] = outputData.data[1];
    data->data[15] = outputData.data[2];
#endif
}

int OriginChannel::readEvents(sensors_event_t* data, int count) {
    int size = mHfLooper->eventRead(data, count);
    for (int i = 0; i < size; ++i) {
        if (data[i].type != SENSOR_TYPE_META_DATA) {
            if (data[i].timestamp < ts_reverse_debug[data[i].type]) {
                ALOGI("sensor time reverse [%d,%" PRId64 ",%" PRId64 "]", data[i].type,
                    ts_reverse_debug[data[i].type], data[i].timestamp);
            }
            ts_reverse_debug[data[i].type] = data[i].timestamp;
            if (data[i].type == SENSOR_TYPE_MAGNETIC_FIELD)
                processMagCalibration(&data[i]);
        }
    }
    return size;
}
