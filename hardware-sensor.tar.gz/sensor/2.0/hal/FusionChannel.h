/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#ifndef _FUSION_SENSOR_H_
#define _FUSION_SENSOR_H_

#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#include <sys/cdefs.h>
#include <sys/types.h>

#include "SensorContext.h"
#include "SensorBase.h"
#include "hwmsen_custom.h"
#include "VendorInterface.h"
#include "MtkInterface.h"
#include "SensorManager.h"
#include "SensorCalibration.h"
#include "HfManager.h"

enum fusion_handle {
    orientation = BaseInterface::ALGO_ORI,
    grv = BaseInterface::ALGO_GRV,
    gmrv = BaseInterface::ALGO_GMRV,
    rv = BaseInterface::ALGO_RV,
    la = BaseInterface::ALGO_LA,
    grav = BaseInterface::ALGO_GRAVITY,
    gyro,
    unacc,
    ungyro,
    unmag,
    gyro_temperature,
    max_fusion_support,
};

struct sensorInfo {
    int mEnabled;
    int64_t samplingPeriodNs;
    int64_t batchReportLatencyNs;
    int dependance;
    bool useAccData;
    bool useGyroData;
    bool useMagData;
};

class FusionChannel : public SensorBase {
private:
    struct sensorInfo mSensorInfo[max_fusion_support];
    int64_t bestSamplingPeriodNs;
    int64_t bestBatchReportLatencyNs;
    int mWritePipeFd;
    int mReadPipeFd;
    BaseInterface *mBaseInterface;
    SensorManager *mSensorManager;
    SensorConnection *mSensorConnection;
    int gyroEnabledCount;
    int accEnabledCount;
    int magEnabledCount;
    SensorCalibration *mSensorCalibration;
    std::unique_ptr<HfLooper> mHfLooper;

protected:
    int reportFlush(int handle);
    int reportData(int handle, const sensorData *data);
    int selectBestSampleLatency();
    int getFusionAndReport(const sensors_event_t *data);
    int getUncaliAccAndReport(const sensors_event_t *data);
    int getUncaliGyroAndReport(const sensors_event_t *data);
    int getUncaliMagAndReport(const sensors_event_t *data);

public:
            FusionChannel();
    virtual ~FusionChannel();
    virtual int getFd();
    virtual int readEvents(sensors_event_t* data, int count);
    virtual int enable(int32_t handle, int enabled);
    virtual int batch(int handle, int flags,
            int64_t samplingPeriodNs, int64_t maxBatchReportLatencyNs);
    virtual int flush(int handle);
    virtual int setEvent(const sensors_event_t *data);
    virtual int setFlushEvent(const sensors_event_t *data);
};
#endif
