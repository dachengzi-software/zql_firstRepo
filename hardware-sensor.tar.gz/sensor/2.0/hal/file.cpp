/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

//#define LOG_NDEBUG    0
#define LOG_TAG "file"
#include <utils/Log.h>
#include "file.h"

#include <fcntl.h>
#include <string.h>
#include <unistd.h>

namespace android {

File::File()
    : mInitCheck(NO_INIT),
      mFd(-1) {
}

File::File(const char *path, const char *mode)
    : mInitCheck(NO_INIT),
      mFd(-1) {
    mInitCheck = setTo(path, mode);
}

File::~File() {
    close();
}

status_t File::initCheck() const {
    return mInitCheck;
}

status_t File::setTo(const char *path, const char *mode) {
    close();

    int modeval = 0;
    if (!strcmp("r", mode)) {
        modeval = O_RDONLY;
    } else if (!strcmp("w", mode)) {
        modeval = O_WRONLY | O_CREAT | O_TRUNC;
    } else if (!strcmp("rw", mode)) {
        modeval = O_RDWR | O_CREAT;
    }

    int filemode = 0;
    if (modeval & O_CREAT) {
        filemode = S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH;
    }

    mFd = TEMP_FAILURE_RETRY(open(path, modeval, filemode));

    mInitCheck = (mFd >= 0) ? OK : -errno;

    return mInitCheck;
}

void File::close() {
    if (mFd >= 0) {
        ::close(mFd);
        mFd = -1;
    }

    mInitCheck = NO_INIT;
}

ssize_t File::read(void *data, size_t size) {
    return ::read(mFd, data, size);
}

ssize_t File::write(const void *data, size_t size) {
    return ::write(mFd, data, size);
}

off64_t File::seekTo(off64_t pos, int whence) {
    off64_t new_pos = lseek64(mFd, pos, whence);
    return new_pos < 0 ? -errno : new_pos;
}

}  // namespace android
