/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <errno.h>
#include <unistd.h>
#include <log/log.h>
#include <string.h>
#include <inttypes.h>

#include <csignal>

#include "hwmsen_custom.h"
#include "SensorSavedChannel.h"

#undef LOG_TAG
#define LOG_TAG "SensorSavedChannel"

#define ACC_TAG_BIAS          "acc_bias"
#define ACC_TAG_CALI          "acc_cali"
#define MAG_TAG_BIAS          "mag_bias"
#define MAG_TAG_CALI          "mag_cali"
#define GYRO_TAG_BIAS         "gyro_bias"
#define GYRO_TAG_CALI         "gyro_cali"
#define GYRO_TAG_TEMP         "gyro_temp"
#define ALS_TAG_CALI          "als_cali"
#define PS_TAG_CALI           "ps_cali"
#define SAR_TAG_CALI          "sar_cali"
#define ACC_BIAS_SAVED_DIR    DEFINE_PATH(ACC_TAG_BIAS)
#define ACC_CALI_SAVED_DIR    DEFINE_PATH(ACC_TAG_CALI)
#define MAG_BIAS_SAVED_DIR    DEFINE_PATH(MAG_TAG_BIAS)
#define MAG_CALI_SAVED_DIR    DEFINE_PATH(MAG_TAG_CALI)
#define GYRO_BIAS_SAVED_DIR   DEFINE_PATH(GYRO_TAG_BIAS)
#define GYRO_CALI_SAVED_DIR   DEFINE_PATH(GYRO_TAG_CALI)
#define GYRO_TEMP_SAVED_DIR   DEFINE_PATH(GYRO_TAG_TEMP)
#define ALS_CALI_SAVED_DIR    DEFINE_PATH(ALS_TAG_CALI)
#define PS_CALI_SAVED_DIR     DEFINE_PATH(PS_TAG_CALI)
#define SAR_CALI_SAVED_DIR    DEFINE_PATH(SAR_TAG_CALI)

static void signal_handler(int /* signal */) {
    pthread_exit(NULL);
}

SensorSavedChannel::SensorSavedChannel() {
    int fd = -1;
    android::SensorSaved mSensorSaved;
    int32_t bias[3] = {0};
    int32_t cali[6] = {0};
    int32_t temp[6] = {0};
    int32_t sendData[12] = {0};

    mHfManager.reset(new HfManager());

    /* start restore acc bias and cali */
    if (!mSensorSaved.getCalibrationInt32(ACC_BIAS_SAVED_DIR, ACC_TAG_BIAS, bias, 3))
        memset(bias, 0, sizeof(bias));
    ALOGI("%s==>[%d,%d,%d]\n", ACC_BIAS_SAVED_DIR, bias[0], bias[1], bias[2]);
    if (!mSensorSaved.getCalibrationInt32(ACC_CALI_SAVED_DIR, ACC_TAG_CALI, cali, 3))
        memset(cali, 0, sizeof(cali));
    ALOGI("%s==>[%d,%d,%d]\n", ACC_CALI_SAVED_DIR, cali[0], cali[1], cali[2]);
    memset(sendData, 0, sizeof(sendData));
    /* dynamic bias */
    sendData[0] = bias[0];
    sendData[1] = bias[1];
    sendData[2] = bias[2];
    /* static cali */
    sendData[3] = cali[0];
    sendData[4] = cali[1];
    sendData[5] = cali[2];
    mHfManager->configCalibration(SENSOR_TYPE_ACCELEROMETER,
        sendData, sizeof(sendData[0]) * 6);

    /* start restore gyro bias cali and temperature */
    if (!mSensorSaved.getCalibrationInt32(GYRO_BIAS_SAVED_DIR, GYRO_TAG_BIAS, bias, 3))
        memset(bias, 0, sizeof(bias));
    ALOGI("%s==>[%d,%d,%d]\n", GYRO_BIAS_SAVED_DIR, bias[0], bias[1], bias[2]);
    if (!mSensorSaved.getCalibrationInt32(GYRO_CALI_SAVED_DIR, GYRO_TAG_CALI, cali, 3))
        memset(cali, 0, sizeof(cali));
    ALOGI("%s==>[%d,%d,%d]\n", GYRO_CALI_SAVED_DIR, cali[0], cali[1], cali[2]);
    if (!mSensorSaved.getCalibrationInt32(GYRO_TEMP_SAVED_DIR, GYRO_TAG_TEMP, temp, 6))
        memset(temp, 0, sizeof(temp));
    ALOGI("%s==>[%d,%d,%d,%d,%d,%d]\n", GYRO_TEMP_SAVED_DIR, temp[0], temp[1], temp[2],
        temp[3], temp[4], temp[5]);
    /* dynamic bias */
    sendData[0] = bias[0];
    sendData[1] = bias[1];
    sendData[2] = bias[2];
    /* static cali */
    sendData[3] = cali[0];
    sendData[4] = cali[1];
    sendData[5] = cali[2];
    /* temperature cali */
    sendData[6] = temp[0];
    sendData[7] = temp[1];
    sendData[8] = temp[2];
    sendData[9] = temp[3];
    sendData[10] = temp[4];
    sendData[11] = temp[5];
    mHfManager->configCalibration(SENSOR_TYPE_GYROSCOPE,
        sendData, sizeof(sendData[0]) * 12);

#ifdef MAG_CALIBRATION_IN_SENSORHUB
    /* start restore mag bias cali */
    if (!mSensorSaved.getCalibrationInt32(MAG_BIAS_SAVED_DIR, MAG_TAG_BIAS, bias, 3))
        memset(bias, 0, sizeof(bias));
    ALOGI("%s==>[%d,%d,%d]\n", MAG_BIAS_SAVED_DIR, bias[0], bias[1], bias[2]);
    if (!mSensorSaved.getCalibrationInt32(MAG_CALI_SAVED_DIR, MAG_TAG_CALI, temp, 6))
        memset(temp, 0, sizeof(temp));
    ALOGI("%s==>[%d,%d,%d,%d,%d,%d]\n", MAG_CALI_SAVED_DIR, temp[0], temp[1], temp[2],
            temp[3], temp[4], temp[5]);
    /* dynamic bias */
    sendData[0] = bias[0];
    sendData[1] = bias[1];
    sendData[2] = bias[2];
    /* static cali */
    sendData[3] = temp[0];
    sendData[4] = temp[1];
    sendData[5] = temp[2];
    sendData[6] = temp[3];
    sendData[7] = temp[4];
    sendData[8] = temp[5];
    mHfManager->configCalibration(SENSOR_TYPE_MAGNETIC_FIELD,
            sendData, sizeof(sendData[0]) * 9);
#endif

    /* start restore light */
    if (!mSensorSaved.getCalibrationInt32(ALS_CALI_SAVED_DIR, ALS_TAG_CALI, cali, 1))
        memset(cali, 0, sizeof(cali));
    ALOGI("%s==>[%d]\n", ALS_CALI_SAVED_DIR, cali[0]);
    sendData[0] = cali[0];
    mHfManager->configCalibration(SENSOR_TYPE_LIGHT,
                sendData, sizeof(sendData[0]) * 1);

    /* start restore proximity */
    if (!mSensorSaved.getCalibrationInt32(PS_CALI_SAVED_DIR, PS_TAG_CALI, cali, 2))
        memset(cali, 0, sizeof(cali));
    ALOGI("%s==>[%d,%d]\n", PS_CALI_SAVED_DIR, cali[0], cali[1]);
    sendData[0] = cali[0];
    sendData[1] = cali[1];
    mHfManager->configCalibration(SENSOR_TYPE_PROXIMITY,
                sendData, sizeof(sendData[0]) * 2);

    /* start restore sar */
    if (!mSensorSaved.getCalibrationInt32(SAR_CALI_SAVED_DIR, SAR_TAG_CALI, cali, 4))
        memset(cali, 0, sizeof(cali));
    ALOGI("%s==>[%d,%d,%d,%d]\n",
        SAR_CALI_SAVED_DIR, cali[0], cali[1], cali[2], cali[3]);
    sendData[0] = cali[0];
    sendData[1] = cali[1];
    sendData[2] = cali[2];
    sendData[3] = cali[3];
    mHfManager->configCalibration(SENSOR_TYPE_SAR,
                sendData, sizeof(sendData[0]) * 4);

    mHfManager->requestRuntimeCalibration(SENSOR_TYPE_ACCELEROMETER, true);
    mHfManager->requestRuntimeCalibration(SENSOR_TYPE_GYROSCOPE, true);
    mHfManager->requestRuntimeCalibration(SENSOR_TYPE_MAGNETIC_FIELD, true);
    mHfManager->requestGyroTemperatureCalibration(true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_ACCELEROMETER, true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_GYROSCOPE, true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_MAGNETIC_FIELD, true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_PROXIMITY, true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_LIGHT, true);
    mHfManager->requestFactoryCalibration(SENSOR_TYPE_SAR, true);
    fd = mHfManager->getFd();
    mLooperThread = std::thread([fd]() {
        std::unique_ptr<HfLooper> mHfLooper(new HfLooper(fd, 8));
        android::SensorSaved mSensorSaved;
        std::signal(SIGQUIT, signal_handler);
        while (1) {
            int err = mHfLooper->eventLooper([&mSensorSaved](sensors_event_t const * event) {
                int32_t bias[3] = {0};
                int32_t cali[6] = {0};

                if (event->reserved0 == BIAS_ACTION) {
                    bias[0] = (int32_t)event->data[0];
                    bias[1] = (int32_t)event->data[1];
                    bias[2] = (int32_t)event->data[2];
                    switch (event->sensor) {
                    case SENSOR_TYPE_ACCELEROMETER:
                        mSensorSaved.saveCalibrationInt32(ACC_BIAS_SAVED_DIR, ACC_TAG_BIAS, bias, 3);
                        ALOGI("[%d,%d,%d]==>%s\n", bias[0], bias[1], bias[2], ACC_BIAS_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_MAGNETIC_FIELD:
                        mSensorSaved.saveCalibrationInt32(MAG_BIAS_SAVED_DIR, MAG_TAG_BIAS, bias, 3);
                        ALOGI("[%d,%d,%d]==>%s\n", bias[0], bias[1], bias[2], MAG_BIAS_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_GYROSCOPE:
                        mSensorSaved.saveCalibrationInt32(GYRO_BIAS_SAVED_DIR, GYRO_TAG_BIAS, bias, 3);
                        ALOGI("[%d,%d,%d]==>%s\n", bias[0], bias[1], bias[2], GYRO_BIAS_SAVED_DIR);
                        break;
                    }
                } else if (event->reserved0 == CALI_ACTION) {
                    switch (event->sensor) {
                    case SENSOR_TYPE_ACCELEROMETER:
                        if (event->acceleration.status) {
                            ALOGI("cali type: %d result fail:%d\n",
                                SENSOR_TYPE_ACCELEROMETER, event->acceleration.status);
                            break;
                        }
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        cali[2] = (int32_t)event->data[2];
                        mSensorSaved.saveCalibrationInt32(ACC_CALI_SAVED_DIR, ACC_TAG_CALI, cali, 3);
                        ALOGI("[%d,%d,%d]==>%s\n", cali[0], cali[1], cali[2], ACC_CALI_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_MAGNETIC_FIELD:
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        cali[2] = (int32_t)event->data[2];
                        cali[3] = (int32_t)event->data[3];
                        cali[4] = (int32_t)event->data[4];
                        cali[5] = (int32_t)event->data[5];
                        mSensorSaved.saveCalibrationInt32(MAG_CALI_SAVED_DIR, MAG_TAG_CALI, cali, 6);
                        ALOGI("[%d,%d,%d,%d,%d,%d]==>%s\n", cali[0], cali[1], cali[2],
                                                cali[3], cali[4], cali[5], MAG_CALI_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_GYROSCOPE:
                        if (event->gyro.status) {
                            ALOGI("cali type: %d result fail:%d\n",
                                SENSOR_TYPE_GYROSCOPE, event->gyro.status);
                            break;
                        }
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        cali[2] = (int32_t)event->data[2];
                        mSensorSaved.saveCalibrationInt32(GYRO_CALI_SAVED_DIR, GYRO_TAG_CALI, cali, 3);
                        ALOGI("[%d,%d,%d]==>%s\n", cali[0], cali[1], cali[2], GYRO_CALI_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_PROXIMITY:
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        mSensorSaved.saveCalibrationInt32(PS_CALI_SAVED_DIR, PS_TAG_CALI, cali, 2);
                        ALOGI("[%d,%d]==>%s\n", cali[0], cali[1], PS_CALI_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_LIGHT:
                        cali[0] = (int32_t)event->data[0];
                        mSensorSaved.saveCalibrationInt32(ALS_CALI_SAVED_DIR, ALS_TAG_CALI, cali, 1);
                        ALOGI("[%d]==>%s\n", cali[0], ALS_CALI_SAVED_DIR);
                        break;
                    case SENSOR_TYPE_SAR:
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        cali[2] = (int32_t)event->data[2];
                        cali[3] = (int32_t)event->data[3];
                        mSensorSaved.saveCalibrationInt32(SAR_CALI_SAVED_DIR, SAR_TAG_CALI, cali, 4);
                        ALOGI("[%d, %d, %d, %d]==>%s\n",
                            cali[0], cali[1], cali[2], cali[3], SAR_CALI_SAVED_DIR);
                        break;
                    }
                } else if (event->reserved0 == TEMP_ACTION) {
                    switch (event->sensor) {
                    case SENSOR_TYPE_GYROSCOPE:
                        cali[0] = (int32_t)event->data[0];
                        cali[1] = (int32_t)event->data[1];
                        cali[2] = (int32_t)event->data[2];
                        cali[3] = (int32_t)event->data[3];
                        cali[4] = (int32_t)event->data[4];
                        cali[5] = (int32_t)event->data[5];
                        mSensorSaved.saveCalibrationInt32(GYRO_TEMP_SAVED_DIR, GYRO_TAG_TEMP, cali, 6);
                        ALOGI("[%d,%d,%d,%d,%d,%d]==>%s\n", cali[0], cali[1], cali[2],
                            cali[3], cali[4], cali[5], GYRO_TEMP_SAVED_DIR);
                        break;
                    }
                }
            });
            switch (err) {
            case -ENODEV:
                ALOGE("looper stop nodevice error\n");
                return;
            }
        };
    });
}

SensorSavedChannel::~SensorSavedChannel() {
    pthread_kill(mLooperThread.native_handle(), SIGQUIT);
    mLooperThread.join();
    mHfManager.reset();
}
