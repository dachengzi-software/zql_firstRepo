/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <fcntl.h>
#include <unistd.h>
#include <log/log.h>
#include <inttypes.h>

#include "hwmsen_custom.h"
#include "FusionChannel.h"

static int HandleToIndex(int handle) {
    int index = -1;

    switch (handle) {
    case SENSOR_TYPE_ORIENTATION:
        index = orientation;
        break;
    case SENSOR_TYPE_GAME_ROTATION_VECTOR:
        index = grv;
        break;
    case SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR:
        index = gmrv;
        break;
    case SENSOR_TYPE_ROTATION_VECTOR:
        index = rv;
        break;
    case SENSOR_TYPE_LINEAR_ACCELERATION:
        index = la;
        break;
    case SENSOR_TYPE_GRAVITY:
        index = grav;
        break;
    case SENSOR_TYPE_GYROSCOPE:
        index = gyro;
        break;
    case SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED:
        index = unacc;
        break;
    case SENSOR_TYPE_GYROSCOPE_UNCALIBRATED:
        index = ungyro;
        break;
    case SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED:
        index = unmag;
        break;
    case SENSOR_TYPE_GYRO_TEMPERATURE:
        index = gyro_temperature;
        break;
    }

    return index;
}

static int IndexToHandle(int index) {
    int handle = -1;

    switch (index) {
    case orientation:
        handle = SENSOR_TYPE_ORIENTATION;
        break;
    case grv:
        handle = SENSOR_TYPE_GAME_ROTATION_VECTOR;
        break;
    case gmrv:
        handle = SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR;
        break;
    case rv:
        handle = SENSOR_TYPE_ROTATION_VECTOR;
        break;
    case la:
        handle = SENSOR_TYPE_LINEAR_ACCELERATION;
        break;
    case grav:
        handle = SENSOR_TYPE_GRAVITY;
        break;
    case gyro:
        handle = SENSOR_TYPE_GYROSCOPE;
        break;
    case unacc:
        handle = SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED;
        break;
    case ungyro:
        handle = SENSOR_TYPE_GYROSCOPE_UNCALIBRATED;
        break;
    case unmag:
        handle = SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED;
        break;
    case gyro_temperature:
        handle = SENSOR_TYPE_GYRO_TEMPERATURE;
        break;
    }

    return handle;
}

#undef LOG_TAG
#define LOG_TAG "FusionChannel"

#define FLOAT_TO_INTEGER 1000000

#define MAX_SAMPLE_DELAY_NS   0x7FFFFFFFFFFFFFFFLL
#define MAX_REPORT_LETANCY_NS 0x7FFFFFFFFFFFFFFFLL

#ifndef MAGNETOMETER_MINDELAY
#define MIN_MAG_SAMPLE_DELAY_NS  20000000
#else
#define MIN_MAG_SAMPLE_DELAY_NS  (MAGNETOMETER_MINDELAY * 1000)
#endif

#ifndef ACCELEROMETER_MINDELAY
#define MIN_ACC_SAMPLE_DELAY_NS  10000000
#else
#define MIN_ACC_SAMPLE_DELAY_NS  (ACCELEROMETER_MINDELAY * 1000)
#endif

#ifndef GYROSCOPE_MINDELAY
#define MIN_GYRO_SAMPLE_DELAY_NS  10000000
#else
#define MIN_GYRO_SAMPLE_DELAY_NS  (GYROSCOPE_MINDELAY * 1000)
#endif

static BaseInterface *selectInterface(void) {
#ifdef FUSION_USE_MTK_ALGORITHM
    return MtkInterface::getInstance();
#else
    return VendorInterface::getInstance();
#endif
}

FusionChannel::FusionChannel() {
    int pipeFds[2] = {-1};

    mWritePipeFd = -1;
    mReadPipeFd = -1;

    memset(mSensorInfo, 0, sizeof(mSensorInfo));
    for (int index = orientation; index < max_fusion_support; ++index) {
        mSensorInfo[index].samplingPeriodNs = MAX_SAMPLE_DELAY_NS;
        mSensorInfo[index].batchReportLatencyNs = MAX_REPORT_LETANCY_NS;
        mSensorInfo[index].useAccData = true;
#ifdef FUSION_SUPPORT_9D_ALGORITHM
        mSensorInfo[index].dependance = SENSOR_TYPE_GYROSCOPE;
        mSensorInfo[index].useGyroData = true;
#else
        mSensorInfo[index].dependance = SENSOR_TYPE_ACCELEROMETER;
        mSensorInfo[index].useGyroData = false;
#endif
        mSensorInfo[index].useMagData = true;
    }
#ifdef FUSION_SUPPORT_9D_ALGORITHM
    mSensorInfo[grv].useMagData = false;
#else
    mSensorInfo[grv].useMagData = true;
#endif
    mSensorInfo[unacc].useAccData = true;
    mSensorInfo[unacc].useGyroData = false;
    mSensorInfo[unacc].useMagData = false;
    mSensorInfo[unacc].dependance = SENSOR_TYPE_ACCELEROMETER;
    mSensorInfo[ungyro].useAccData = false;
    mSensorInfo[ungyro].useGyroData = true;
    mSensorInfo[ungyro].useMagData = false;
    mSensorInfo[ungyro].dependance = SENSOR_TYPE_GYROSCOPE;
    mSensorInfo[unmag].useAccData = false;
    mSensorInfo[unmag].useGyroData = false;
    mSensorInfo[unmag].useMagData = true;
    mSensorInfo[unmag].dependance = SENSOR_TYPE_MAGNETIC_FIELD;
    bestSamplingPeriodNs = MAX_SAMPLE_DELAY_NS;
    bestBatchReportLatencyNs = MAX_REPORT_LETANCY_NS;
    gyroEnabledCount = 0;
    accEnabledCount = 0;
    magEnabledCount = 0;

    mBaseInterface = selectInterface();
    mSensorManager = SensorManager::getInstance();
    mSensorConnection = mSensorManager->createSensorConnection(FUSION_CHANNEL);
    mSensorCalibration = SensorCalibration::getInstance();

    if (pipe(pipeFds) < 0)
        ALOGE("error creating pipe (%s)\n", strerror(errno));
    if (fcntl(pipeFds[0], F_SETFL, O_NONBLOCK) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    if (fcntl(pipeFds[1], F_SETFL, O_NONBLOCK) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    /*
     * pipe_size default is 64kb, we resize to 512kb for all fusion enable,
     * 512kb buffer can contain 5000 events
     */
    if (fcntl(pipeFds[0], F_SETPIPE_SZ, 512*1024) < 0)
        ALOGE("error manipulate file descriptor (%s)\n", strerror(errno));
    mWritePipeFd = pipeFds[1];
    mReadPipeFd = pipeFds[0];

    mHfLooper.reset(new HfLooper(getFd(), 128, false));
    /* pipe fd should set gain */
    mHfLooper->setGain(SENSOR_TYPE_ORIENTATION, 1000);
    mHfLooper->setGain(SENSOR_TYPE_ROTATION_VECTOR, 1000000);
    mHfLooper->setGain(SENSOR_TYPE_GAME_ROTATION_VECTOR, 1000000);
    mHfLooper->setGain(SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR, 1000000);
    mHfLooper->setGain(SENSOR_TYPE_LINEAR_ACCELERATION, 1000);
    mHfLooper->setGain(SENSOR_TYPE_GRAVITY, 1000);
    mHfLooper->setGain(SENSOR_TYPE_GYROSCOPE, 1000000);
    mHfLooper->setGain(SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED, 1000);
    mHfLooper->setGain(SENSOR_TYPE_GYROSCOPE_UNCALIBRATED, 1000000);
    mHfLooper->setGain(SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED, 1000);
}

FusionChannel::~FusionChannel() {
    mBaseInterface = NULL;
    mSensorManager->removeSensorConnection(mSensorConnection);
    mSensorManager = NULL;
    mHfLooper.reset();
}

int FusionChannel::getFd() {
    return mReadPipeFd;
}

int FusionChannel::reportFlush(int handle) {
    struct hf_manager_event event;

    memset(&event, 0, sizeof(struct hf_manager_event));
    event.sensor_type = handle;
    event.action = FLUSH_ACTION;
    if (write(mWritePipeFd, &event, sizeof(struct hf_manager_event)) < 0)
        ALOGE("sensortype(%d) write flush to mWriteFd failed\n", handle);
    return 0;
}

int FusionChannel::reportData(int handle, const sensorData *data) {
    uint32_t gain = mHfLooper->getGain(handle);
    struct hf_manager_event event;

    memset(&event, 0, sizeof(struct hf_manager_event));
    event.sensor_type = handle;
    event.timestamp = data->timeStamp;
    event.action = DATA_ACTION;
    event.accurancy= data->status;
    event.word[0] = data->data[0] * gain;
    event.word[1] = data->data[1] * gain;
    event.word[2] = data->data[2] * gain;
    event.word[3] = data->data[3] * gain;
    event.word[4] = data->data[4] * gain;
    event.word[5] = data->data[5] * gain;
    if (write(mWritePipeFd, &event, sizeof(struct hf_manager_event)) < 0)
        ALOGE("sensortype(%d) write data to mWriteFd failed\n", handle);
    return 0;
}

int FusionChannel::selectBestSampleLatency(void) {
    for (int index = orientation; index < max_fusion_support; ++index) {
        if (mSensorInfo[index].mEnabled) {
            if (bestSamplingPeriodNs > mSensorInfo[index].samplingPeriodNs) {
                bestSamplingPeriodNs = mSensorInfo[index].samplingPeriodNs;
            }
            if (bestBatchReportLatencyNs > mSensorInfo[index].batchReportLatencyNs) {
                bestBatchReportLatencyNs = mSensorInfo[index].batchReportLatencyNs;
            }
        }
    }
    if (bestSamplingPeriodNs < 0)
        bestSamplingPeriodNs = 0;
    if (bestBatchReportLatencyNs < 0)
        bestBatchReportLatencyNs = 0;
    if (bestBatchReportLatencyNs >= MAX_REPORT_LETANCY_NS)
        bestBatchReportLatencyNs = MAX_REPORT_LETANCY_NS;

    /* ALOGI("bestSamplingPeriodNs:%" PRId64 ", bestBatchReportLatencyNs:%" PRId64 "\n",
        bestSamplingPeriodNs, bestBatchReportLatencyNs); */
    return 0;
}

int FusionChannel::getUncaliAccAndReport(const sensors_event_t *data) {
    struct sensorData outputData;

    memset(&outputData, 0, sizeof(struct sensorData));
    if (mSensorInfo[unacc].mEnabled) {
        // raw data
        outputData.data[0] = data->data[0] + data->data[13];
        outputData.data[1] = data->data[1] + data->data[14];
        outputData.data[2] = data->data[2] + data->data[15];
        // bias
        outputData.data[3] = data->data[13];
        outputData.data[4] = data->data[14];
        outputData.data[5] = data->data[15];
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED, &outputData);
    }
    return 0;
}

int FusionChannel::getUncaliGyroAndReport(const sensors_event_t *data) {
    struct sensorData outputData;

    memset(&outputData, 0, sizeof(struct sensorData));
    if (mSensorInfo[ungyro].mEnabled) {
        outputData.data[0] = data->data[0] + data->data[13];
        outputData.data[1] = data->data[1] + data->data[14];
        outputData.data[2] = data->data[2] + data->data[15];
        // bias
        outputData.data[3] = data->data[13];
        outputData.data[4] = data->data[14];
        outputData.data[5] = data->data[15];
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_GYROSCOPE_UNCALIBRATED, &outputData);
    }
    return 0;
}

int FusionChannel::getUncaliMagAndReport(const sensors_event_t *data) {
    struct sensorData outputData;

    memset(&outputData, 0, sizeof(struct sensorData));
    if (mSensorInfo[unmag].mEnabled) {
        outputData.data[0] = data->data[0] + data->data[13];
        outputData.data[1] = data->data[1] + data->data[14];
        outputData.data[2] = data->data[2] + data->data[15];
        // bias
        outputData.data[3] = data->data[13];
        outputData.data[4] = data->data[14];
        outputData.data[5] = data->data[15];
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED, &outputData);
    }
    return 0;
}

int FusionChannel::getFusionAndReport(const sensors_event_t *data) {
    struct sensorData outputData;

    memset(&outputData, 0, sizeof(struct sensorData));
    if (mSensorInfo[orientation].mEnabled &&
            mSensorInfo[orientation].dependance == data->sensor) {
        mBaseInterface->getOrientation(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_ORIENTATION, &outputData);
    }
    if (mSensorInfo[grv].mEnabled &&
            mSensorInfo[grv].dependance == data->sensor) {
        mBaseInterface->getGameRotationVector(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_GAME_ROTATION_VECTOR, &outputData);
    }
    if (mSensorInfo[gmrv].mEnabled &&
            mSensorInfo[gmrv].dependance == data->sensor) {
        mBaseInterface->getGeoMagnetic(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR, &outputData);
    }
    if (mSensorInfo[rv].mEnabled &&
            mSensorInfo[rv].dependance == data->sensor) {
        mBaseInterface->getRotationVector(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_ROTATION_VECTOR, &outputData);
    }
    if (mSensorInfo[la].mEnabled &&
            mSensorInfo[la].dependance == data->sensor) {
        mBaseInterface->getLinearaccel(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_LINEAR_ACCELERATION, &outputData);
    }
    if (mSensorInfo[grav].mEnabled &&
            mSensorInfo[grav].dependance == data->sensor) {
        mBaseInterface->getGravity(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_GRAVITY, &outputData);
    }
    if (mSensorInfo[gyro].mEnabled &&
            mSensorInfo[gyro].dependance == data->sensor) {
        mBaseInterface->getGravity(&outputData);
        outputData.timeStamp = data->timestamp;
        reportData(SENSOR_TYPE_GYROSCOPE, &outputData);
    }
    return 0;
}

int FusionChannel::enable(int32_t handle, int en) {
    int index = -1, total = 0;
    int64_t samplingPeriodNs = 0;

    ALOGI("activate: [%d,%d]", handle, en);

    index = HandleToIndex(handle);
    if (index < 0) {
        ALOGE("HandleToIndex err, handle:%d, index:%d\n", handle, index);
        return -1;
    }

    if (en) {
        mSensorInfo[index].mEnabled = true;
        mBaseInterface->enableAlgo((enum BaseInterface::fusion_algo)index);
        selectBestSampleLatency();
        /* gyro enable */
        if (mSensorInfo[index].useGyroData) {
            if (bestSamplingPeriodNs < MIN_GYRO_SAMPLE_DELAY_NS)
                samplingPeriodNs = MIN_GYRO_SAMPLE_DELAY_NS;
            else
                samplingPeriodNs = bestSamplingPeriodNs;
            if (!gyroEnabledCount++) {
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_GYROSCOPE,
                    samplingPeriodNs, bestBatchReportLatencyNs);
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_GYROSCOPE, true);
            }
        }
        /* acc enable */
        if (mSensorInfo[index].useAccData) {
            if (bestSamplingPeriodNs < MIN_ACC_SAMPLE_DELAY_NS)
                samplingPeriodNs = MIN_ACC_SAMPLE_DELAY_NS;
            else
                samplingPeriodNs = bestSamplingPeriodNs;
            if (!accEnabledCount++) {
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_ACCELEROMETER,
                    samplingPeriodNs, bestBatchReportLatencyNs);
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_ACCELEROMETER, true);
            }
        }
        /* mag enable */
        if (mSensorInfo[index].useMagData) {
            if (bestSamplingPeriodNs < MIN_MAG_SAMPLE_DELAY_NS)
                samplingPeriodNs = MIN_MAG_SAMPLE_DELAY_NS;
            else
                samplingPeriodNs = bestSamplingPeriodNs;
            if (!magEnabledCount++) {
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_MAGNETIC_FIELD,
                    samplingPeriodNs, bestBatchReportLatencyNs);
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_MAGNETIC_FIELD, true);
            }
        }
    } else {
        mSensorInfo[index].mEnabled = false;
        mBaseInterface->disableAlgo((enum BaseInterface::fusion_algo)index);
        mSensorInfo[index].samplingPeriodNs = MAX_SAMPLE_DELAY_NS;
        mSensorInfo[index].batchReportLatencyNs = MAX_REPORT_LETANCY_NS;
        selectBestSampleLatency();
        /* gyro disable */
        if (mSensorInfo[index].useGyroData) {
            if (!--gyroEnabledCount) {
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_GYROSCOPE, false);
            } else if (gyroEnabledCount > 0) {
                if (bestSamplingPeriodNs < MIN_GYRO_SAMPLE_DELAY_NS)
                    samplingPeriodNs = MIN_GYRO_SAMPLE_DELAY_NS;
                else
                    samplingPeriodNs = bestSamplingPeriodNs;
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_GYROSCOPE,
                    samplingPeriodNs, bestBatchReportLatencyNs);
            } else
                gyroEnabledCount = 0;
        }
        /* acc disable */
        if (mSensorInfo[index].useAccData) {
            if (!--accEnabledCount) {
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_ACCELEROMETER, false);
            } else if (accEnabledCount > 0) {
                if (bestSamplingPeriodNs < MIN_ACC_SAMPLE_DELAY_NS)
                    samplingPeriodNs = MIN_ACC_SAMPLE_DELAY_NS;
                else
                    samplingPeriodNs = bestSamplingPeriodNs;
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_ACCELEROMETER,
                    samplingPeriodNs, bestBatchReportLatencyNs);
            } else
                accEnabledCount = 0;
        }
        /* mag disable */
        if (mSensorInfo[index].useMagData) {
            if (!--magEnabledCount) {
                mSensorManager->activate(mSensorConnection, SENSOR_TYPE_MAGNETIC_FIELD, false);
            } else if (magEnabledCount > 0) {
                if (bestSamplingPeriodNs < MIN_MAG_SAMPLE_DELAY_NS)
                    samplingPeriodNs = MIN_MAG_SAMPLE_DELAY_NS;
                else
                    samplingPeriodNs = bestSamplingPeriodNs;
                mSensorManager->batch(mSensorConnection, SENSOR_TYPE_MAGNETIC_FIELD,
                    samplingPeriodNs, bestBatchReportLatencyNs);
            } else
                magEnabledCount = 0;
        }
        /* reset best batch params */
        for (int index = orientation; index < max_fusion_support; ++index) {
            total += mSensorInfo[index].mEnabled;
        }
        if (!total) {
            bestSamplingPeriodNs = MAX_SAMPLE_DELAY_NS;
            bestBatchReportLatencyNs = MAX_REPORT_LETANCY_NS;
        }
    }
    return 0;
}

int FusionChannel::batch(int handle, int /* flags */,
        int64_t samplingPeriodNs, int64_t maxBatchReportLatencyNs) {
    int index = -1;
    int64_t tmpSamplingPeriodNs;

    ALOGI("batch: [%d,%" PRId64 ",%" PRId64 "]\n",
        handle, samplingPeriodNs, maxBatchReportLatencyNs);

    index = HandleToIndex(handle);
    if (index < 0) {
        ALOGE("HandleToIndex err, handle:%d, index:%d\n", handle, index);
        return -1;
    }

    mSensorInfo[index].samplingPeriodNs = samplingPeriodNs;
    mSensorInfo[index].batchReportLatencyNs = maxBatchReportLatencyNs;
    selectBestSampleLatency();

    /* gyro batch */
    if (mSensorInfo[index].useGyroData) {
        if (bestSamplingPeriodNs < MIN_GYRO_SAMPLE_DELAY_NS)
            tmpSamplingPeriodNs = MIN_GYRO_SAMPLE_DELAY_NS;
        else
            tmpSamplingPeriodNs = bestSamplingPeriodNs;
        if (gyroEnabledCount)
            mSensorManager->batch(mSensorConnection, SENSOR_TYPE_GYROSCOPE,
                tmpSamplingPeriodNs, bestBatchReportLatencyNs);
    }
    /* acc batch */
    if (mSensorInfo[index].useAccData) {
        if (bestSamplingPeriodNs < MIN_ACC_SAMPLE_DELAY_NS)
            tmpSamplingPeriodNs = MIN_ACC_SAMPLE_DELAY_NS;
        else
            tmpSamplingPeriodNs = bestSamplingPeriodNs;
        if (accEnabledCount)
            mSensorManager->batch(mSensorConnection, SENSOR_TYPE_ACCELEROMETER,
                tmpSamplingPeriodNs, bestBatchReportLatencyNs);
    }
    /* mag batch */
    if (mSensorInfo[index].useMagData) {
        if (bestSamplingPeriodNs < MIN_MAG_SAMPLE_DELAY_NS)
            tmpSamplingPeriodNs = MIN_MAG_SAMPLE_DELAY_NS;
        else
            tmpSamplingPeriodNs = bestSamplingPeriodNs;
        if (magEnabledCount)
            mSensorManager->batch(mSensorConnection, SENSOR_TYPE_MAGNETIC_FIELD,
                tmpSamplingPeriodNs, bestBatchReportLatencyNs);
    }
    return 0;
}

int FusionChannel::flush(int handle) {
    int err = -1, index = -1;

    ALOGI("flush: [%d]", handle);
    index = HandleToIndex(handle);
    if (index < 0) {
        ALOGE("HandleToIndex err, handle:%d, index:%d\n", handle, index);
        return -1;
    }

    if (mSensorInfo[index].dependance == SENSOR_TYPE_ACCELEROMETER ||
            mSensorInfo[index].dependance == SENSOR_TYPE_GYROSCOPE ||
                mSensorInfo[index].dependance == SENSOR_TYPE_MAGNETIC_FIELD)
        err = mSensorManager->flush(mSensorConnection, mSensorInfo[index].dependance);
    else
        err = -1;
    return err;
}

int FusionChannel::setEvent(const sensors_event_t *data) {
    struct sensorData inputData;

    //ALOGD("handle=%d x=%f, y=%f, z=%f\n", data->sensor, data->data[0], data->data[1], data->data[2]);

    memset(&inputData, 0, sizeof(struct sensorData));

    inputData.timeStamp = data->timestamp;
    inputData.data[0] = data->data[0];
    inputData.data[1] = data->data[1];
    inputData.data[2] = data->data[2];
    if (data->sensor == SENSOR_TYPE_ACCELEROMETER) {
        inputData.status = data->acceleration.status;
        mBaseInterface->setAccData(&inputData);
        getUncaliAccAndReport(data);
        getFusionAndReport(data);
    } else if (data->sensor == SENSOR_TYPE_GYROSCOPE) {
        inputData.status = data->gyro.status;
        mBaseInterface->setGyroData(&inputData);
        getUncaliGyroAndReport(data);
        getFusionAndReport(data);
    } else if (data->sensor == SENSOR_TYPE_MAGNETIC_FIELD) {
        inputData.status = data->magnetic.status;
        mBaseInterface->setMagData(&inputData);
        getUncaliMagAndReport(data);
    }
    return 0;
}

int FusionChannel::setFlushEvent(const sensors_event_t *data) {
    for (int index = orientation; index < max_fusion_support; ++index) {
        if (mSensorInfo[index].dependance == data->meta_data.sensor)
            reportFlush(IndexToHandle(index));
    }
    return 0;
}

int FusionChannel::readEvents(sensors_event_t* data, int count) {
    return mHfLooper->eventRead(data, count);
}
