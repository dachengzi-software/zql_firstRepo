/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#ifndef JSON_OBJECT_H_

#define JSON_OBJECT_H_

#include <media/stagefright/foundation/ABase.h>
#include <media/stagefright/foundation/AString.h>
#include <utils/Errors.h>
#include <utils/KeyedVector.h>
#include <utils/RefBase.h>
#include <utils/Vector.h>

namespace android {

struct JSONArray;
struct JSONCompound;
struct JSONObject;

struct JSONValue {
    enum FieldType {
        TYPE_STRING,
        TYPE_INT32,
        TYPE_FLOAT,
        TYPE_BOOLEAN,
        TYPE_NULL,
        TYPE_OBJECT,
        TYPE_ARRAY,
    };

    // Returns the number of bytes consumed or an error.
    static ssize_t Parse(const char *data, size_t size, JSONValue *out);

    JSONValue();
    JSONValue(const JSONValue &);
    JSONValue &operator=(const JSONValue &);
    ~JSONValue();

    FieldType type() const;
    bool getInt32(int32_t *value) const;
    bool getFloat(float *value) const;
    bool getString(AString *value) const;
    bool getBoolean(bool *value) const;
    bool getObject(sp<JSONObject> *value) const;
    bool getArray(sp<JSONArray> *value) const;

    void setInt32(int32_t value);
    void setFloat(float value);
    void setString(const AString &value);
    void setBoolean(bool value);
    void setObject(const sp<JSONObject> &obj);
    void setArray(const sp<JSONArray> &array);
    void unset();  // i.e. setNull()

    AString toString(size_t depth = 0, bool indentFirstLine = true) const;

private:
    FieldType mType;

    union {
        int32_t mInt32;
        float mFloat;
        AString *mString;
        bool mBoolean;
        JSONCompound *mObjectOrArray;
    } mValue;
};

struct JSONCompound : public RefBase {
    static sp<JSONCompound> Parse(const char *data, size_t size);

    AString toString(size_t depth = 0, bool indentFirstLine = true) const;

    virtual bool isObject() const = 0;

protected:
    virtual ~JSONCompound() {}

    virtual AString internalToString(size_t depth) const = 0;

    JSONCompound() {}

private:
    friend struct JSONValue;

    DISALLOW_EVIL_CONSTRUCTORS(JSONCompound);
};

template<class KEY>
struct JSONBase : public JSONCompound {
    JSONBase() {}

#define PREAMBLE()                              \
    JSONValue value;                            \
    if (!getValue(key, &value)) {               \
        return false;                           \
    }

    bool getFieldType(KEY key, JSONValue::FieldType *type) const {
        PREAMBLE()
        *type = value.type();
        return true;
    }

    bool getInt32(KEY key, int32_t *out) const {
        PREAMBLE()
        return value.getInt32(out);
    }

    bool getFloat(KEY key, float *out) const {
        PREAMBLE()
        return value.getFloat(out);
    }

    bool getString(KEY key, AString *out) const {
        PREAMBLE()
        return value.getString(out);
    }

    bool getBoolean(KEY key, bool *out) const {
        PREAMBLE()
        return value.getBoolean(out);
    }

    bool getObject(KEY key, sp<JSONObject> *obj) const {
        PREAMBLE()
        return value.getObject(obj);
    }

    bool getArray(KEY key, sp<JSONArray> *obj) const {
        PREAMBLE()
        return value.getArray(obj);
    }

#undef PREAMBLE

protected:
    virtual ~JSONBase() {}

    virtual bool getValue(KEY key, JSONValue *value) const = 0;

private:
    DISALLOW_EVIL_CONSTRUCTORS(JSONBase);
};

struct JSONObject : public JSONBase<const char *> {
    JSONObject();

    virtual bool isObject() const;
    void setValue(const char *key, const JSONValue &value);

    void setInt32(const char *key, int32_t in) {
        JSONValue val;
        val.setInt32(in);
        setValue(key, val);
    }

    void setFloat(const char *key, float in) {
        JSONValue val;
        val.setFloat(in);
        setValue(key, val);
    }

    void setString(const char *key, AString in) {
        JSONValue val;
        val.setString(in);
        setValue(key, val);
    }

    void setBoolean(const char *key, bool in) {
        JSONValue val;
        val.setBoolean(in);
        setValue(key, val);
    }

    void setObject(const char *key, const sp<JSONObject> &obj) {
        JSONValue val;
        val.setObject(obj);
        setValue(key, val);
    }

    void setArray(const char *key, const sp<JSONArray> &obj) {
        JSONValue val;
        val.setArray(obj);
        setValue(key, val);
    }

protected:
    virtual ~JSONObject();

    virtual bool getValue(const char *key, JSONValue *value) const;
    virtual AString internalToString(size_t depth) const;

private:
    KeyedVector<AString, JSONValue> mValues;

    DISALLOW_EVIL_CONSTRUCTORS(JSONObject);
};

struct JSONArray : public JSONBase<size_t> {
    JSONArray();

    virtual bool isObject() const;
    size_t size() const;
    void addValue(const JSONValue &value);

    void addInt32(int32_t in) {
        JSONValue val;
        val.setInt32(in);
        addValue(val);
    }

    void addFloat(float in) {
        JSONValue val;
        val.setFloat(in);
        addValue(val);
    }

    void addString(AString in) {
        JSONValue val;
        val.setString(in);
        addValue(val);
    }

    void addBoolean(bool in) {
        JSONValue val;
        val.setBoolean(in);
        addValue(val);
    }

    void addObject(const sp<JSONObject> &obj) {
        JSONValue val;
        val.setObject(obj);
        addValue(val);
    }

    void addArray(const sp<JSONArray> &obj) {
        JSONValue val;
        val.setArray(obj);
        addValue(val);
    }

protected:
    virtual ~JSONArray();

    virtual bool getValue(size_t key, JSONValue *value) const;
    virtual AString internalToString(size_t depth) const;


private:
    Vector<JSONValue> mValues;

    DISALLOW_EVIL_CONSTRUCTORS(JSONArray);
};

}  // namespace android

#endif  // JSON_OBJECT_H_
