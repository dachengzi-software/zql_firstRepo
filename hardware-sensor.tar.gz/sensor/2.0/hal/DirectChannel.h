/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#ifndef _DIRECTCHANNEL_H_
#define _DIRECTCHANNEL_H_

#include <cutils/native_handle.h>
#include <hardware/gralloc.h>
#include <hardware/gralloc1.h>
#include <hardware/sensors.h>
#include <utils/Singleton.h>
#include <memory>

struct LockfreeBuffer {
    LockfreeBuffer(void* buf, size_t size);
    ~LockfreeBuffer();

    // support single writer
    void write(const sensors_event_t *ev, size_t size);
private:
    sensors_event_t *mData;
    size_t mSize;
    size_t mWritePos;
    int32_t mCounter;
};

class DirectChannelBase {
public:
    DirectChannelBase() : mError(android::NO_INIT), mSize(0), mBase(nullptr) { }
    virtual ~DirectChannelBase() {}
    virtual bool memoryMatches(const struct sensors_direct_mem_t *mem) const = 0;

    bool isValid();
    int getError();
    void write(const sensors_event_t * ev);

protected:
    int mError;
    std::unique_ptr<LockfreeBuffer> mBuffer;

    size_t mSize;
    void* mBase;
};

class AshmemDirectChannel : public DirectChannelBase {
public:
    AshmemDirectChannel(const struct sensors_direct_mem_t *mem);
    ~AshmemDirectChannel() override;
    bool memoryMatches(const struct sensors_direct_mem_t *mem) const override;
private:
    int mAshmemFd;
};

class GrallocHalWrapper : public android::Singleton<GrallocHalWrapper> {
public:
    int registerBuffer(const native_handle_t *handle);
    int unregisterBuffer(const native_handle_t *handle);
    int lock(const native_handle_t *handle, int usage, int l, int t, int w, int h, void **vaddr);
    int unlock(const native_handle_t *handle);
    bool isSameMemory(const native_handle_t *h1, const native_handle_t *h2);
    bool unregisterImplyDelete() { return mUnregisterImplyDelete; }

private:
    friend class android::Singleton<GrallocHalWrapper>;
    GrallocHalWrapper();
    ~GrallocHalWrapper();
    static int mapGralloc1Error(int grallocError);

    int mError;
    int mVersion;
    gralloc_module_t *mGrallocModule;
    // gralloc
    alloc_device_t *mAllocDevice;

    // gralloc1
    gralloc1_device_t *mGralloc1Device;
    GRALLOC1_PFN_RETAIN mPfnRetain;
    GRALLOC1_PFN_RELEASE mPfnRelease;
    GRALLOC1_PFN_LOCK mPfnLock;
    GRALLOC1_PFN_UNLOCK mPfnUnlock;
    GRALLOC1_PFN_GET_BACKING_STORE mPfnGetBackingStore;
    bool mUnregisterImplyDelete;
};

class GrallocDirectChannel : public DirectChannelBase {
public:
    GrallocDirectChannel(const struct sensors_direct_mem_t *mem);
    ~GrallocDirectChannel() override;
    bool memoryMatches(const struct sensors_direct_mem_t *mem) const override;
private:
    native_handle_t *mNativeHandle;
};
#endif  // DIRECTCHANNEL_H_
