/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <hardware/sensors.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include <poll.h>

#include <log/log.h>
#include <inttypes.h>

#include "SensorContext.h"
#include "SensorList.h"
#include "HfSensorType.h"
#include "hwmsen_custom.h"

#include "OriginChannel.h"
#include "FusionChannel.h"
#include "WakeupChannel.h"

#undef LOG_TAG
#define LOG_TAG "SensorContext"

static int dynamicFusionSelect(void) {
#ifdef MAG_CALIBRATION_IN_SENSORHUB
#ifdef FUSION_ALGORITHM_IN_SENSORHUB
    return ORIGIN_CHANNEL;
#else
    return FUSION_CHANNEL;
#endif
#else
    return FUSION_CHANNEL;
#endif
}

static int dynamicGyroSelect(void) {
    bool what = SensorList::getInstance()->hwGyroSupported();
    return what ? ORIGIN_CHANNEL : FUSION_CHANNEL;
}

static int findChannel(int sensor_handle) {
    switch (sensor_handle) {
        case SENSOR_TYPE_ACCELEROMETER:
        case SENSOR_TYPE_MAGNETIC_FIELD:
        case SENSOR_TYPE_LIGHT:
        case SENSOR_TYPE_PRESSURE:
        case SENSOR_TYPE_TEMPERATURE:
        case SENSOR_TYPE_PROXIMITY:
        case SENSOR_TYPE_RELATIVE_HUMIDITY:
        case SENSOR_TYPE_AMBIENT_TEMPERATURE:
        case SENSOR_TYPE_SIGNIFICANT_MOTION:
        case SENSOR_TYPE_STEP_DETECTOR:
        case SENSOR_TYPE_STEP_COUNTER:
        case SENSOR_TYPE_HEART_RATE:
        case SENSOR_TYPE_TILT_DETECTOR:
        case SENSOR_TYPE_WAKE_GESTURE:
        case SENSOR_TYPE_GLANCE_GESTURE:
        case SENSOR_TYPE_PICK_UP_GESTURE:
        case SENSOR_TYPE_WRIST_TILT_GESTURE:
        case SENSOR_TYPE_DEVICE_ORIENTATION:
        case SENSOR_TYPE_POSE_6DOF:
        case SENSOR_TYPE_STATIONARY_DETECT:
        case SENSOR_TYPE_MOTION_DETECT:
        case SENSOR_TYPE_HEART_BEAT:
        case SENSOR_TYPE_DYNAMIC_SENSOR_META:
        case SENSOR_TYPE_ADDITIONAL_INFO:
        case SENSOR_TYPE_LOW_LATENCY_OFFBODY_DETECT:
        case SENSOR_TYPE_PEDOMETER:
        case SENSOR_TYPE_IN_POCKET:
        case SENSOR_TYPE_ACTIVITY:
        case SENSOR_TYPE_PDR:
        case SENSOR_TYPE_FREEFALL:
        case SENSOR_TYPE_FLAT:
        case SENSOR_TYPE_FACE_DOWN:
        case SENSOR_TYPE_SHAKE:
        case SENSOR_TYPE_BRINGTOSEE:
        case SENSOR_TYPE_ANSWER_CALL:
        case SENSOR_TYPE_GEOFENCE:
        case SENSOR_TYPE_FLOOR_COUNTER:
        case SENSOR_TYPE_EKG:
        case SENSOR_TYPE_PPG1:
        case SENSOR_TYPE_PPG2:
        case SENSOR_TYPE_RGBW:
        case SENSOR_TYPE_GYRO_TEMPERATURE:
        case SENSOR_TYPE_SAR:
        case SENSOR_TYPE_OIS:
            return ORIGIN_CHANNEL;
        case SENSOR_TYPE_GYROSCOPE:
            return dynamicGyroSelect();
        case SENSOR_TYPE_ORIENTATION:
        case SENSOR_TYPE_GRAVITY:
        case SENSOR_TYPE_LINEAR_ACCELERATION:
        case SENSOR_TYPE_ROTATION_VECTOR:
        case SENSOR_TYPE_GAME_ROTATION_VECTOR:
        case SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR:
            return dynamicFusionSelect();
        case SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED:
        case SENSOR_TYPE_GYROSCOPE_UNCALIBRATED:
        case SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED:
            return FUSION_CHANNEL;
        case SENSOR_TYPE_STEP_DETECTOR_WAKEUP:
            return WAKEUP_CHANNEL;
    }
    return -EINVAL;
}

sensors_poll_context_t *sensors_poll_context_t::contextInstance = nullptr;
sensors_poll_context_t *sensors_poll_context_t::getInstance() {
    if (contextInstance == nullptr) {
        sensors_poll_context_t *context = new sensors_poll_context_t;
        contextInstance = context;
    }
    return contextInstance;
}

sensors_poll_context_t::sensors_poll_context_t()
{
    memset(&device, 0, sizeof(device));

    mSensorSavedChannel = new SensorSavedChannel();

    mSensors[ORIGIN_CHANNEL] = new OriginChannel();
    mPollFds[ORIGIN_CHANNEL].fd = mSensors[ORIGIN_CHANNEL]->getFd();
    mPollFds[ORIGIN_CHANNEL].events = POLLIN;
    mPollFds[ORIGIN_CHANNEL].revents = 0;

    mSensors[FUSION_CHANNEL] = new FusionChannel();
    mPollFds[FUSION_CHANNEL].fd = mSensors[FUSION_CHANNEL]->getFd();
    mPollFds[FUSION_CHANNEL].events = POLLIN;
    mPollFds[FUSION_CHANNEL].revents = 0;

    mSensors[WAKEUP_CHANNEL] = new WakeupChannel();
    mPollFds[WAKEUP_CHANNEL].fd = mSensors[WAKEUP_CHANNEL]->getFd();
    mPollFds[WAKEUP_CHANNEL].events = POLLIN;
    mPollFds[WAKEUP_CHANNEL].revents = 0;
}

sensors_poll_context_t::~sensors_poll_context_t() {
    delete mSensorSavedChannel;
    for (int i = 0; i < MAX_CHANNEL; i++) {
        delete mSensors[i];
    }
    contextInstance = nullptr;
}

int sensors_poll_context_t::activate(int handle, int enabled) {
    int channel = findChannel(handle);

    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return -1;
    return mSensors[channel]->enable(handle, enabled);
}

int sensors_poll_context_t::setDelay(int handle, int64_t ns) {
    int channel = findChannel(handle);

    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return -1;
    return mSensors[channel]->batch(handle, 0, ns, 0);
}

int sensors_poll_context_t::batch(int handle, int flags,
            int64_t samplingPeriodNs, int64_t maxBatchReportLatencyNs) {
    int channel = findChannel(handle);

    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return -1;
    return mSensors[channel]->batch(handle, flags,
                samplingPeriodNs, maxBatchReportLatencyNs);
}

int sensors_poll_context_t::flush(int handle) {
    int channel = findChannel(handle);

    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return -1;
    return mSensors[channel]->flush(handle);
}

void sensors_poll_context_t::computeCountForEachFd(int count,
            int *average, int *loop) {
    int pendingFd = 0;

    for (int i = 0; i < MAX_CHANNEL; i++) {
        if (mPollFds[i].revents & POLLIN)
            pendingFd++;
    }
    int temp = pendingFd ? count / pendingFd : count;
    *average = temp ? temp : count;
    *loop = (count < pendingFd) ? 1 : pendingFd;
}

int sensors_poll_context_t::pollEvent(sensors_event_t* data, int count) {
    int nbEvents = 0;
    int n = 0;
    int averageCount = 0, loop = 0, loopcount = 0;
    int backupcount = count, backuploop = 0;

    do {
        loopcount++;
        computeCountForEachFd(count, &averageCount, &loop);
        backuploop = loop;
        for (int i = 0; count && loop && i < MAX_CHANNEL; i++) {
            SensorBase* const sensor(mSensors[i]);
            if (mPollFds[i].revents & POLLIN) {
                int nb = sensor->readEvents(data, averageCount);
                if (nb < 0 || nb > averageCount) {
                    ALOGE("pollEvents nb:%d, averageCount:%d, loop:%d, "
                              "backupcount:%d, loopcount:%d, backuploop:%d\n",
                        nb, averageCount, loop, backupcount, loopcount, backuploop);
                    abort();
                }
                count -= nb;
                nbEvents += nb;
                data += nb;
                loop--;
                if (count < 0) {
                    ALOGE("pollEvents count:%d, nbEvents:%d, nb:%d, "
                              "averageCount:%d, loop:%d, backupcount:%d, "
                                  "loopcount:%d, backuploop:%d\n",
                        count, nbEvents, nb, averageCount, loop, backupcount,
                            loopcount, backuploop);
                    abort();
                }
            }
        }
        // try to see if we can get some events immediately or just wait if
        // we don't have anything to return, important to update fd revents
        // which sensor data pending in buffer and aviod one sensor always
        // occupy poll bandwidth.
        n = TEMP_FAILURE_RETRY(poll(mPollFds, MAX_CHANNEL, nbEvents ? 0 : -1));
        if (n < 0) {
            ALOGE("poll() failed (%s)", strerror(errno));
            return -errno;
        }
    } while (n && count);
    return nbEvents;
}

int sensors_poll_context_t::setEvent(const sensors_event_t *data, int channel) {
    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return 0;
    return mSensors[channel]->setEvent(data);
}

int sensors_poll_context_t::setFlushEvent(const sensors_event_t *data, int channel) {
    if (channel >= MAX_CHANNEL || channel < 0 || !mSensors[channel])
        return 0;
    return mSensors[channel]->setFlushEvent(data);
}
