/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#ifndef _HF_MANAGER_H_
#define _HF_MANAGER_H_

#include <fcntl.h>
#include <poll.h>

#include <mutex>
#include <bitset>
#include <memory>
#include <mutex>

#include <hardware/sensors.h>

#include "HfSensorType.h"
#include "HfSensorIo.h"

typedef struct sensor_info {
    uint8_t sensor_type;
    uint32_t gain;
    char name[16];
    char vendor[16];
} sensor_info;

typedef struct custom_cmd {
    int32_t data[16];
} custom_cmd;

enum custom_action {
    CUST_CMD_CALI = 0,
    /*Add custom cmd action here!*/
};

class HfManager {
public:
    HfManager();
    ~HfManager();

    int getFd(void);
    int findSensor(int sensor);
    int activateSensor(int sensor, int enabled);
    int batchSensor(int sensor, int64_t delayNs, int64_t latencyNs);
    int flushSensor(int sensor);
    int enableSensor(int sensor, int64_t delayNs);
    int enableSensor(int sensor, int64_t delayNs, int64_t latencyNs);
    int disableSensor(int sensor);
    int requestFactoryCalibration(int sensor, bool status);
    int requestRuntimeCalibration(int sensor, bool status);
    int requestGyroTemperatureCalibration(bool status);
    int requestSelfTest(int sensor, bool status);
    int requestCustomCmd(int sensor, struct custom_cmd *cust_cmd);
    int enableFactoryCalibration(int sensor);
    int configCalibration(int sensor, void *data, size_t length);
    int enableSelfTest(int sensor);
    int enableRawData(int sensor);
    int disableRawData(int sensor);
    int getSensorInfo(int sensor, sensor_info *info);

protected:
    int initCheck() const;
    int enableDisable(int sensor, int enable,
        int64_t delayNs, int64_t latencyNs);
    void disableAllSensor(void);
    void disableActiveSensor(void);
    bool checkRegisterStatus(int sensor);
    int requestOperation(int sensor, unsigned int cmd, bool status);
    int enableDisableRawData(int sensor, int en);

private:
    int mFd;
    std::bitset<SENSOR_TYPE_SENSOR_MAX> sensorState;
    std::bitset<SENSOR_TYPE_SENSOR_MAX> sensorRegister;
    int64_t mDelayNs[SENSOR_TYPE_SENSOR_MAX];
    int64_t mLatencyNs[SENSOR_TYPE_SENSOR_MAX];
    std::mutex mStateLock;
};

class HfLooper {
public:
    HfLooper(int fd, int pollBufferSize, bool hasManager = true);
    ~HfLooper();
    /* for other user loop data */
    int eventLooper(std::function<void(sensors_event_t const *)> callback);
    int eventLooper(sensors_event_t *data, int count);
    int eventLooper(sensors_event_t *data, int count, int timeout);
    int eventLooperSignal(sensors_event_t *data, int count);
    /* for sensorservice user read data, only contain data and flush */
    int eventRead(sensors_event_t *data, int count);
    void setGain(int sensor, uint32_t gain);
    uint32_t getGain(int sensor);

protected:
    int initCheck() const;
    int eventConvertAll(sensors_event_t *dst, hf_manager_event *src);
    int eventConvertOther(sensors_event_t *dst, hf_manager_event *src);
    int eventConvertData(sensors_event_t *dst, hf_manager_event *src);
    int eventConvertDataFlush(sensors_event_t *dst, hf_manager_event *src);
    void getSensorInfo(int fd, bool hasManager);

private:
    static constexpr int pollMaxBufferSize = 32;

    int mFd;
    int mPollBufferSize;
    struct pollfd mPollFds[1];
    int mNumPollFds;
    std::unique_ptr<hf_manager_event[]> pollBuffer;
    sensor_info info[SENSOR_TYPE_SENSOR_MAX];
};
#endif
