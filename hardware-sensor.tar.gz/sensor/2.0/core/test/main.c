/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <inttypes.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>

#include <HfManagerWrapper.h>

pthread_t looperThread;

static void signal_handler0(int signal) {
    fprintf(stderr, "cwrapper signal_handler0=%d (%d,%d)\n", signal, getpid(), gettid());
    pthread_kill(looperThread, SIGQUIT);
}

static void signal_handler1(int signal) {
    fprintf(stderr, "cwrapper signal_handler1=%d (%d,%d)\n", signal, getpid(), gettid());
    pthread_exit(NULL);
}

static void *looperThreadRun(void *mHfLooper) {
    sensors_event_t data[32];

    fprintf(stderr, "cwrapper looperThreadRun (%d,%d)\n", getpid(), gettid());

    signal(SIGQUIT, signal_handler1);

    while (1) {
        int err = HfLooperEventLooper(mHfLooper, data, 32);
        switch (err) {
            case -ENODEV:
            fprintf(stderr, "cwrapper looper stop nodevice error\n");
            return NULL;
        }
        for (int i = 0; i < err; ++i) {
            fprintf(stderr, "cwrapper data: [%d,%d,%" PRId64 ",%f,%f,%f]\n",
                    data[i].sensor, data[i].reserved0, data[i].timestamp,
                        data[i].data[0], data[i].data[1], data[i].data[2]);
        }
    }
}

int main(int argc, char **argv) {
    int sensor = 0, action = 0, delay = 0, latency = 0;

    if (argc != 5) {
        fprintf(stderr, "usage:         execute        sensor  action  delay  latency\n");
        fprintf(stderr, "       ./high_freq_sensor_tool   1       1   5000000    0\n");
        return -1;
    }

    /* register handler for sigint(crtl+c) */
    signal(SIGINT, signal_handler0);

    sensor = atoi(argv[1]);
    action = atoi(argv[2]);
    delay = atoi(argv[3]);
    latency = atoi(argv[4]);

    fprintf(stderr, "cwrapper mainThread (%d,%d)\n", getpid(), gettid());
    fprintf(stderr, "cwrapper command: [%d,%d,%d,%d]\n", sensor, action, delay, latency);

    void *mHfManager = HfManagerCreate();
    void *mHfLooper = HfLooperCreate(HfManagerGetFd(mHfManager), 64);

    pthread_create(&looperThread, NULL, looperThreadRun, mHfLooper);

    if (HfManagerFindSensor(mHfManager, sensor) < 0)
        return -2;
    switch (action) {
    case HF_MANAGER_SENSOR_DISABLE:
        HfManagerDisableSensor(mHfManager, sensor);
        break;
    case HF_MANAGER_SENSOR_ENABLE:
        HfManagerEnableSensor(mHfManager, sensor, delay, latency);
        break;
    case HF_MANAGER_SENSOR_RAWDATA:
        HfManagerEnableRawData(mHfManager, sensor);
        break;
    }

    /* wait looperthread exit */
    pthread_join(looperThread, NULL);
    HfLooperDestroy(mHfLooper);
    HfManagerDestroy(mHfManager);
    fprintf(stderr, "cwrapper mainThread exit\n");
    return 0;
}
