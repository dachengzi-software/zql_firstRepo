/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <inttypes.h>

#include <memory>
#include <vector>
#include <thread>
#include <csignal>

#include <HfManager.h>
#include "pSensorCalibration.h"

#define TOOL_VERSION "2916768"

typedef struct {
    int64_t value[4];
} command;

static std::thread looperThread;
static std::unique_ptr<PSensorCali> mPSensorCali;

static void signal_handler0(int signal) {
    fprintf(stderr, "signal_handler0=%d (%d,%d)\n", signal, getpid(), gettid());
    int ret = pthread_kill(looperThread.native_handle(), SIGQUIT);
    if (ret)
        fprintf(stderr, "signal_handler0, kill loopthread failed ret:%d\n", ret);

    if (mPSensorCali && mPSensorCali->getNativeHandle())
        pthread_kill(mPSensorCali->getNativeHandle(), SIGUSR1);
}

static void signal_handler1(int signal) {
    fprintf(stderr, "signal_handler1=%d (%d,%d)\n", signal, getpid(), gettid());
    pthread_exit(NULL);
}

static void printUsage(bool status) {
    if (status)
        fprintf(stderr, "Command Line Execute Wrong!\n");
    fprintf(stderr, "Usage:\n");
    fprintf(stderr, "    ./high_freq_sensor_tool -v\n");
    fprintf(stderr, "    ./high_freq_sensor_tool -h\n");
    fprintf(stderr, "    ./high_freq_sensor_tool -c 1,1,5000000,0\n");
    fprintf(stderr, "    ./high_freq_sensor_tool -c 1,1,5000000,0 -c 2,1,20000000,0\n");
}

int main(int argc, char **argv) {
    std::vector<command> cmdline;
    int foundSensorCount = 0;
    int32_t config_value[2] = {0};

    if (argc == 1) {
        printUsage(true);
        return -1;
    }

    while (1) {
        int c = getopt(argc, argv, "c:vh");
        if (c == -1) {
            break;
        }
        switch (c) {
            case 'c': {
                int i;
                command cmd;

                i = 0;
                memset(&cmd, 0, sizeof(cmd));
                char *token = strtok(optarg, ",");
                while (token && i < sizeof(cmd.value) / sizeof(cmd.value[0])) {
                    cmd.value[i++] = atoll(token);
                    token = strtok(NULL, ",");
                }
                cmdline.push_back(cmd);
                break;
            }
            case 'v': {
                fprintf(stderr, "high_freq_sensor_tool Version %s\n", TOOL_VERSION);
                return 0;
            }
            case 'h': {
                printUsage(false);
                return 0;
            }
            default: {
                printUsage(true);
                return -2;
            }
        }
    }

    if (!cmdline.size()) {
        printUsage(true);
        return -2;
    }

    fprintf(stderr, "mainThread (%d,%d)\n", getpid(), gettid());

    /* register handler for sigint(crtl+c) */
    std::signal(SIGINT, signal_handler0);

    std::unique_ptr<HfManager> mHfManager(new HfManager());
    looperThread = std::thread([&mHfManager]() {
        fprintf(stderr, "looperThread (%d,%d)\n", getpid(), gettid());
        std::unique_ptr<HfLooper> mHfLooper(new HfLooper(mHfManager->getFd(), 64));
        /* register handler for sigquit */
        std::signal(SIGQUIT, signal_handler1);
        while (1) {
            int err = mHfLooper->eventLooper([&mHfManager](sensors_event_t const * event) {
                switch (event->sensor) {
                    case SENSOR_TYPE_ACCELEROMETER:
                        fprintf(stderr, "data: [%d,%d,%" PRId64 ",%f,%f,%f,%d]\n",
                            event->sensor, event->reserved0, event->timestamp,
                            event->acceleration.x, event->acceleration.y, event->acceleration.z,
                            event->acceleration.status);
                    break;
                    case SENSOR_TYPE_GYROSCOPE:
                        fprintf(stderr, "data: [%d,%d,%" PRId64 ",%f,%f,%f,%d]\n",
                            event->sensor, event->reserved0, event->timestamp,
                            event->gyro.x, event->gyro.y, event->gyro.z,
                            event->gyro.status);
                    break;
                    default:
                        fprintf(stderr, "data: [%d,%d,%" PRId64 ",%f,%f,%f]\n",
                            event->sensor, event->reserved0, event->timestamp,
                            event->data[0], event->data[1], event->data[2]);
                    break;
                }
                switch (event->reserved0) {
                case CALI_ACTION:
                    mHfManager->requestFactoryCalibration(event->sensor, false);
                break;
                }
            });
            switch (err) {
            case -ENODEV:
                fprintf(stderr, "looper stop nodevice error\n");
                return;
            }
        };
        fprintf(stderr, "looperThread exit\n");
    });

    for (auto it = cmdline.begin(); it != cmdline.end(); ++it) {
        fprintf(stderr, "command: [%" PRId64 ",%" PRId64 ",%" PRId64 ",%" PRId64 "]\n",
            it->value[0], it->value[1], it->value[2], it->value[3]);

        int foundSensor = mHfManager->findSensor(it->value[0]);
        if (foundSensor < 0) {
            fprintf(stderr, "find Sensor(%" PRId64 ") failed(ret:%d), skip this sensor\n",
                it->value[0], foundSensor);
            continue;
        }
        foundSensorCount++;

        switch (it->value[1]) {
        case HF_MANAGER_SENSOR_DISABLE:
            mHfManager->disableSensor(it->value[0]);
            break;
        case HF_MANAGER_SENSOR_ENABLE:
            mHfManager->enableSensor(it->value[0], it->value[2], it->value[3]);
            break;
        case HF_MANAGER_SENSOR_ENABLE_CALI:
            switch (it->value[0]) {
            case SENSOR_TYPE_PROXIMITY:
                mPSensorCali.reset(new PSensorCali());
                break;
            default:
                mHfManager->requestFactoryCalibration(it->value[0], true);
                mHfManager->enableFactoryCalibration(it->value[0]);
                break;
            }
            break;
        case HF_MANAGER_SENSOR_CONFIG_CALI:
            switch (it->value[0]) {
            case SENSOR_TYPE_PROXIMITY:
                config_value[0] = it->value[2];
                config_value[1] = it->value[3];
                mHfManager->configCalibration(it->value[0], config_value, sizeof(int32_t) * 2);
                mHfManager->enableFactoryCalibration(it->value[0]);
                break;
            default:
                config_value[0] = it->value[2];
                config_value[1] = it->value[3];
                mHfManager->configCalibration(it->value[0], config_value, sizeof(int32_t) * 2);
                break;
            }
            break;
        case HF_MANAGER_SENSOR_RAWDATA:
            mHfManager->enableRawData(it->value[0]);
            break;
        }
    }

    if (!foundSensorCount) {
        fprintf(stderr, "no supported sensor found, kill loopthread and mainThread exit(-3)!\n");

        int thdState = pthread_kill(looperThread.native_handle(), SIGQUIT);
        if (thdState)
            fprintf(stderr, "kill loopthread failed ret:%d!\n", thdState);
        return -3;
    }

    /* wait looperthread exit */
    looperThread.join();
    if (mPSensorCali && mPSensorCali->getNativeHandle())
        mPSensorCali->joinThread();

    fprintf(stderr, "mainThread exit\n");
    return 0;
}
