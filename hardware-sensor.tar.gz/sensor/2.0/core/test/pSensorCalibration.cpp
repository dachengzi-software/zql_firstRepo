/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <unistd.h>
#include <csignal>
#include "pSensorCalibration.h"
#include <hardware/sensors.h>
#include "HfSensorType.h"

#define SENSOR_SAMPLE_PERIOD_NS 20000000

void PSensorCali::signal_handler(int signal) {
    fprintf(stderr, "P-Sensor cali fail\n");
    pthread_exit(NULL);
}

PSensorCali::PSensorCali() {
    mHfManager.reset(new HfManager());
    mHfLooper.reset(new HfLooper(mHfManager->getFd(), 64));
    mThread = std::thread(wrapperThread, this);
}

PSensorCali::~PSensorCali() {
    closePSensor();
    mHfManager.reset();
    mHfLooper.reset();
}

void PSensorCali::caliThread(void) {
    int min = 0, max = 0;
    int err = 0;

    fprintf(stderr, "psCaliThread (%d,%d)\n", getpid(), gettid());
    /* register handler for sigquit */
    std::signal(SIGUSR1, signal_handler);

    min = getMinValue();
    if (min < 0) {
        fprintf(stderr, "P-Sensor cali fail\n");
        return;
    }
    max = getMaxValue();
    if (max < 0) {
        fprintf(stderr, "P-Sensor cali fail\n");
        return;
    }
    err = doCalibration(min, max);
    if (err < 0)
        fprintf(stderr, "P-Sensor cali fail\n");
}

void PSensorCali::wrapperThread(PSensorCali *p) {
    p->caliThread();
}

int PSensorCali::getMinValue() {
    int ps_min = 0xffff;
    int sample_count = 0;
    int err = 0;

    fprintf(stderr, "Please put phone on a horizontal plane.\nNOTE: Donot cover P-Sensor.\n");
    fprintf(stderr, "Press 'y' to start calibration or 'n' to exit: ");

    while (1) {
        char c = getchar();
        if (c == 'y' || c == 'Y')
            break;
        if (c == 'n' || c == 'N')
            return -1;
    }

    err = mHfManager->enableSensor(SENSOR_TYPE_PROXIMITY, SENSOR_SAMPLE_PERIOD_NS, 0);
    if (err < 0) {
        fprintf(stderr, "P-Sensor open fail\n");
        return -1;
    }

    mHfManager->enableRawData(SENSOR_TYPE_PROXIMITY);
    fprintf(stderr, "P-Sensor is sampling min value now, please wait... \n");

    do {
        int err = mHfLooper->eventLooper([&](sensors_event_t const * event) {
            if (event->reserved0 == RAW_ACTION) {
                sample_count++;
                if (ps_min > (int)event->data[0])
                    ps_min = (int)event->data[0];
            }
        });

        switch (err) {
        case -ENODEV:
            fprintf(stderr, "P-Sensor cali stop, nodevice error\n");
            return -1;
        }
    } while (sample_count <= 20);

    mHfManager->disableRawData(SENSOR_TYPE_PROXIMITY);
    mHfManager->disableSensor(SENSOR_TYPE_PROXIMITY);
    fprintf(stderr, "P-Sensor get min value success:%d\n", ps_min);
    return ps_min;
}

int PSensorCali::getMaxValue() {
    int ps_max = 0;
    int sample_count = 0;

    fprintf(stderr, "Please cover the P-Sensor.\n");
    fprintf(stderr, "Press 'y' to start calibration or 'n' to exit: ");

    while (1) {
        char c = getchar();
        if (c == 'y' || c == 'Y')
            break;
        if (c == 'n' || c == 'N')
            return -1;
    }

    mHfManager->enableSensor(SENSOR_TYPE_PROXIMITY, SENSOR_SAMPLE_PERIOD_NS, 0);
    mHfManager->enableRawData(SENSOR_TYPE_PROXIMITY);
    fprintf(stderr, "P-Sensor is sampling max value now, please wait... \n");

    do {
        int err = mHfLooper->eventLooper([&](sensors_event_t const * event) {
            if (event->reserved0 == RAW_ACTION) {
                sample_count++;
                if (ps_max < (int)event->data[0]) {
                    ps_max = (int)event->data[0];
                }
            }
        });

        switch (err) {
        case -ENODEV:
            fprintf(stderr, "P-Sensor cali stop, nodevice error\n");
            return -1;
        }
    } while (sample_count <= 20);

    mHfManager->disableRawData(SENSOR_TYPE_PROXIMITY);
    mHfManager->disableSensor(SENSOR_TYPE_PROXIMITY);
    fprintf(stderr, "P-Sensor calculate max value success:%d\n", ps_max);
    return ps_max;
}

int PSensorCali::calculatePsensorUnitValue() {
    int unit = 0;
    int sample_count = 0;
    int ps_min_smallest = 0;
    int ps_min_largest = 0;

    mHfManager->enableSensor(SENSOR_TYPE_PROXIMITY, SENSOR_SAMPLE_PERIOD_NS, 0);
    mHfManager->enableRawData(SENSOR_TYPE_PROXIMITY);

    do {
        int err = mHfLooper->eventLooper([&](sensors_event_t const * event) {
            static int ps_rawdata_temp = 0;
            if (event->reserved0 == RAW_ACTION) {
                sample_count++;
                ps_rawdata_temp = (int)event->data[0];

                if(sample_count == 1)
                    ps_min_largest = ps_min_smallest = ps_rawdata_temp;

                if (ps_min_smallest > ps_rawdata_temp)
                    ps_min_smallest = ps_rawdata_temp;
                else if ((ps_min_largest < ps_rawdata_temp))
                    ps_min_largest = ps_rawdata_temp;
                fprintf(stderr, "PS UnitValue[min,max,raw]=[%d, %d, %d]\n",
                    ps_min_smallest, ps_min_largest, ps_rawdata_temp);
            }
        });

        switch (err) {
        case -ENODEV:
            fprintf(stderr, "P-Sensor cali stop, nodevice error\n");
            return -1;
        }
    } while (sample_count < 10);

    mHfManager->disableRawData(SENSOR_TYPE_PROXIMITY);
    mHfManager->disableSensor(SENSOR_TYPE_PROXIMITY);

    unit = ps_min_largest - ps_min_smallest;
    fprintf(stderr, "P-Sensor unit=[%d],[%d, %d]\n",
        unit, ps_min_smallest, ps_min_largest);
    return unit;
}

int PSensorCali::doCalibration(unsigned int min, unsigned int max) {
    int32_t threshold[2] = {0};
    int unit = 0;

    if (max <= min) {
        fprintf(stderr, "max value is not suitable for calibration, fail!\n");
        return -1;
    }

    fprintf(stderr, "Press 'y' to start P-Sensor calibration or 'n' to exit: ");

    while (1) {
        char c = getchar();
        if (c == 'y' || c == 'Y')
            break;
        if (c == 'n' || c == 'N')
            return -1;
    }

    fprintf(stderr, "P-Sensor is doing calibration now, please wait... \n");

    unit = calculatePsensorUnitValue();
    if (unit < 0) {
        fprintf(stderr, "calculate unit fail(%s), P-Sensor cali exit\n", strerror(errno));
        return -1;
    }
    fprintf(stderr, "P-Sensor, delta:%u unit:%u \n", (max - min) / 3, unit);

    if (((max - min) / 3) > (2 * unit)) {
        threshold[0] = min + (max - min) / 3;
        threshold[1] = min + (max - min) / 3 - unit * 2;
    } else if (((max - min) / 3) > unit) {
        threshold[0] = min + (max - min) / 3;
        threshold[1] = min + (max - min) / 3 - unit;
    } else {
        fprintf(stderr, "P-Sensor hw may have problem, cali fail\n");
        return -1;
    }

    if (threshold[1] > threshold[0] || threshold[1] <= 0
        || threshold[0] <=0) {
        fprintf(stderr, "cali threshold_low error\n");
        return -1;
    }

    fprintf(stderr, "P-Sensor threshold:%d, %d\n", threshold[0], threshold[1]);
    if (!mHfManager->configCalibration(SENSOR_TYPE_PROXIMITY, (void *)threshold, sizeof(threshold)))
        fprintf(stderr, "P-Sensor calibration success\n");
    else
        fprintf(stderr, "P-Sensor calibration fail\n");

    mHfManager->enableFactoryCalibration(SENSOR_TYPE_PROXIMITY);

    return 0;
}

int PSensorCali::closePSensor() {
    mHfManager->disableRawData(SENSOR_TYPE_PROXIMITY);
    mHfManager->disableSensor(SENSOR_TYPE_PROXIMITY);
    return 0;
}

