/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#undef LOG_TAG
#define LOG_TAG "HfManager"

#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <poll.h>
#include <fcntl.h>
#include <inttypes.h>

#include <mutex>

#include <log/log.h>

#include "HfManager.h"

#define HF_MANAGER_NODE_PATH "/dev/hf_manager"

HfManager::HfManager() {
    bool status = false;

    sensorState.reset();
    sensorRegister.reset();

    memset(mDelayNs, 0, sizeof(mDelayNs));
    memset(mLatencyNs, 0, sizeof(mLatencyNs));

    mFd = TEMP_FAILURE_RETRY(open(HF_MANAGER_NODE_PATH, O_RDWR));
    if (mFd < 0) {
        ALOGE("open device failed err=%d errno=%d\n", mFd, errno);
        return;
    }

    for (int sensor = 0; sensor < SENSOR_TYPE_SENSOR_MAX; ++sensor) {
        status = checkRegisterStatus(sensor);
        sensorRegister.set(sensor, status);
    }

    disableAllSensor();
}

HfManager::~HfManager() {
    disableActiveSensor();
    close(mFd);
}

int HfManager::getFd(void) {
    return mFd;
}

int HfManager::initCheck() const {
    return mFd < 0 ? -ENODEV : 0;
}

int HfManager::findSensor(int sensor) {
    if (sensor >= SENSOR_TYPE_SENSOR_MAX)
        return -1;
    int status = sensorRegister.test(sensor);
    return !status ? -1 : sensor;
}

int HfManager::activateSensor(int sensor, int enabled) {
    if (findSensor(sensor) < 0)
        return -1;
    std::unique_lock<std::mutex> lock(mStateLock);
    if (enabled) {
        return enableDisable(sensor, HF_MANAGER_SENSOR_ENABLE,
            mDelayNs[sensor], mLatencyNs[sensor]);
    } else {
        return enableDisable(sensor, HF_MANAGER_SENSOR_DISABLE, 0, 0);
    }
    return 0;
}

int HfManager::batchSensor(int sensor, int64_t delayNs, int64_t latencyNs) {
    if (findSensor(sensor) < 0)
        return -1;
    int err = 0;
    std::unique_lock<std::mutex> lock(mStateLock);
    if (sensorState.test(sensor)) {
        err = enableDisable(sensor, HF_MANAGER_SENSOR_ENABLE,
            delayNs, latencyNs);
        /*
         * for android framework:
         * rebatch(change rate after enable) fail shouldn't reset state,
         * sensorservice sequence: batch,enable(app1 5hz) rebatch(app2 50hz),
         * when rebatch(app2) fail if we reset state, then app3 200hz request
         * can't send to kernel.
         */
        if (err < 0)
            sensorState.set(sensor, 1);
    } else {
        mDelayNs[sensor] = delayNs;
        mLatencyNs[sensor] = latencyNs;
    }
    return err;
}

int HfManager::flushSensor(int sensor) {
    hf_manager_cmd cmd;

    if (initCheck() < 0)
        return -1;

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = HF_MANAGER_SENSOR_FLUSH;
    cmd.sensor_type = sensor;
    return TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
}

int HfManager::enableSensor(int sensor, int64_t delayNs) {
    std::unique_lock<std::mutex> lock(mStateLock);
    return enableDisable(sensor, HF_MANAGER_SENSOR_ENABLE, delayNs, 0);
}

int HfManager::enableSensor(int sensor, int64_t delayNs, int64_t latencyNs) {
    std::unique_lock<std::mutex> lock(mStateLock);
    return enableDisable(sensor, HF_MANAGER_SENSOR_ENABLE, delayNs, latencyNs);
}

int HfManager::disableSensor(int sensor) {
    std::unique_lock<std::mutex> lock(mStateLock);
    return enableDisable(sensor, HF_MANAGER_SENSOR_DISABLE, 0, 0);
}

int HfManager::enableDisable(int sensor, int enable,
        int64_t delayNs, int64_t latencyNs) {
    int err = 0;
    hf_manager_cmd cmd;

    if (initCheck() < 0)
        return -1;

    if (enable == HF_MANAGER_SENSOR_ENABLE)
        sensorState.set(sensor, 1);
    else if (enable == HF_MANAGER_SENSOR_DISABLE)
        sensorState.set(sensor, 0);

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = enable;
    cmd.sensor_type = sensor;
    cmd.delay = delayNs;
    cmd.latency = latencyNs;
    err = TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
    /* enableDisable fail should reset state */
    if (err < 0)
        sensorState.set(sensor, 0);
    return err;
}

void HfManager::disableAllSensor(void) {
    std::unique_lock<std::mutex> lock(mStateLock);
    for (int sensor = 0; sensor < SENSOR_TYPE_SENSOR_MAX; ++sensor) {
        if (sensorRegister.test(sensor))
            enableDisable(sensor, HF_MANAGER_SENSOR_DISABLE, 0, 0);
    }
}

void HfManager::disableActiveSensor(void) {
    std::unique_lock<std::mutex> lock(mStateLock);
    for (size_t sensor = 0; sensor < sensorState.size(); ++sensor) {
        if (sensorState.test(sensor))
            enableDisable(sensor, HF_MANAGER_SENSOR_DISABLE, 0, 0);
    }
}

bool HfManager::checkRegisterStatus(int sensor) {
    int err = -1;
    ioctl_packet packet;

    if ((err = initCheck()) < 0)
        return false;

    memset(&packet, 0, sizeof(packet));
    packet.sensor_type = sensor;

    err = TEMP_FAILURE_RETRY(ioctl(mFd,
            HF_MANAGER_REQUEST_REGISTER_STATUS, &packet));
    if (err < 0) {
        ALOGE("get sensor register failed err=%d errno=%d\n", err, errno);
        return false;
    }
    return packet.status ? true : false;
}

int HfManager::enableFactoryCalibration(int sensor) {
    hf_manager_cmd cmd;

    if (initCheck() < 0)
        return -1;

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = HF_MANAGER_SENSOR_ENABLE_CALI;
    cmd.sensor_type = sensor;
    return TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
}

int HfManager::configCalibration(int sensor, void *data, size_t length) {
    hf_manager_cmd cmd;
    size_t dst_length = 0;

    if (initCheck() < 0)
        return -1;

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = HF_MANAGER_SENSOR_CONFIG_CALI;
    cmd.sensor_type = sensor;
    dst_length = sizeof(cmd.data);
    dst_length = (dst_length < length) ? dst_length : length;
    memcpy(cmd.data, data, dst_length);
    return TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
}

int HfManager::enableSelfTest(int sensor) {
    hf_manager_cmd cmd;

    if (initCheck() < 0)
        return -1;

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = HF_MANAGER_SENSOR_SELFTEST;
    cmd.sensor_type = sensor;
    return TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
}

int HfManager::enableDisableRawData(int sensor, int en) {
    hf_manager_cmd cmd;

    if (initCheck() < 0)
        return -1;

    memset(&cmd, 0, sizeof(cmd));
    cmd.action = HF_MANAGER_SENSOR_RAWDATA;
    cmd.sensor_type = sensor;
    cmd.data[0] = en;
    return TEMP_FAILURE_RETRY(write(mFd, &cmd, sizeof(cmd)));
}

int HfManager::enableRawData(int sensor) {
    return enableDisableRawData(sensor, true);
}

int HfManager::disableRawData(int sensor) {
    return enableDisableRawData(sensor, false);
}

int HfManager::requestOperation(int sensor,
            unsigned int cmd, bool status) {
    int err = -1;
    ioctl_packet packet;

    if ((err = initCheck()) < 0)
        return err;

    memset(&packet, 0, sizeof(packet));
    packet.sensor_type = sensor;
    packet.status = status;

    err = TEMP_FAILURE_RETRY(ioctl(mFd, cmd, &packet));
    if (err < 0) {
        ALOGE("requestOperation failed err=%d errno=%d\n", err, errno);
        return err;
    }
    return err;
}

int HfManager::requestRuntimeCalibration(int sensor, bool status) {
    return requestOperation(sensor, HF_MANAGER_REQUEST_BIAS_DATA, status);
}

int HfManager::requestFactoryCalibration(int sensor, bool status) {
    return requestOperation(sensor, HF_MANAGER_REQUEST_CALI_DATA, status);
}

int HfManager::requestGyroTemperatureCalibration(bool status) {
    return requestOperation(SENSOR_TYPE_GYROSCOPE,
        HF_MANAGER_REQUEST_TEMP_DATA, status);
}

int HfManager::requestSelfTest(int sensor, bool status) {
    return requestOperation(sensor, HF_MANAGER_REQUEST_TEST_DATA, status);
}

int HfManager::getSensorInfo(int sensor, sensor_info *info) {
    int err = -1;
    ioctl_packet packet;

    if ((err = initCheck()) < 0)
        return err;

    memset(&packet, 0, sizeof(packet));
    packet.sensor_type = sensor;
    err = TEMP_FAILURE_RETRY(ioctl(mFd,
        HF_MANAGER_REQUEST_SENSOR_INFO, &packet));
    if (err < 0) {
        ALOGE("getSensorInfo failed err=%d errno=%d\n", err, errno);
        return err;
    }
    memcpy(info, packet.byte, sizeof(*info));
    return 0;
}

/*API for user implement their own operations,
 * use enum "custom_action"to fill at cust_cmd->data[0]
 * to distinguish defferent ops.
 */
int HfManager::requestCustomCmd(int sensor, struct custom_cmd *cust_cmd) {
    int err = -1;
    ioctl_packet packet;

    if ((err = initCheck()) < 0)
        return err;

    memset(&packet, 0, sizeof(packet));
    packet.sensor_type = sensor;
    if (sizeof(packet.byte) < sizeof(cust_cmd->data))
        return err;
    memcpy(packet.byte, cust_cmd->data, sizeof(cust_cmd->data));

    err = TEMP_FAILURE_RETRY(ioctl(mFd, HF_MANAGER_REQUEST_CUST_DATA, &packet));
    if (err < 0) {
        ALOGE("requestCustomData failed err=%d errno=%d\n", err, errno);
        return err;
    }
    memcpy(cust_cmd->data, packet.byte, sizeof(cust_cmd->data));

    return err;
}

#undef LOG_TAG
#define LOG_TAG "HfLooper"

HfLooper::HfLooper(int fd, int pollBufferSize, bool hasManager) {
    mPollBufferSize = (pollBufferSize > pollMaxBufferSize) ?
        pollBufferSize : pollMaxBufferSize;
    pollBuffer.reset(new hf_manager_event[mPollBufferSize]);

    mFd = fd;
    mPollFds[0].fd = fd;
    mPollFds[0].events = POLLIN | POLLMSG;
    mPollFds[0].revents = 0;
    mNumPollFds = 1;
    getSensorInfo(fd, hasManager);
}

HfLooper::~HfLooper() {
    mPollFds[0].fd = mFd = -1;
    /* must close fd then pollBuffer delete, wait poll return */
    pollBuffer.reset();
}

int HfLooper::initCheck() const {
    return mFd < 0 ? -ENODEV : 0;
}

int HfLooper::eventConvertOther(sensors_event_t *dst, hf_manager_event *src) {
    if (src->action != DATA_ACTION && src->action != FLUSH_ACTION) {
        eventConvertAll(dst, src);
        return true;
    }
    return false;
}

int HfLooper::eventConvertData(sensors_event_t *dst, hf_manager_event *src) {
    if (src->action == DATA_ACTION) {
        eventConvertAll(dst, src);
        return true;
    }
    return false;
}

int HfLooper::eventConvertDataFlush(sensors_event_t *dst, hf_manager_event *src) {
    if (src->action == DATA_ACTION || src->action == FLUSH_ACTION) {
        eventConvertAll(dst, src);
        return true;
    }
    return false;
}

int HfLooper::eventConvertAll(sensors_event_t *dst, hf_manager_event *src) {
    uint32_t gain = 1;

    if (src->sensor_type < SENSOR_TYPE_SENSOR_MAX)
        gain = info[src->sensor_type].gain;
    /* data[0, 1, 2, 3, 4, 5] bias cali temp or selftest result */
    /* reserved0 restore action for sensor user dispatch */
    /* data[13, 14, 15] restore bias for uncali sensor */
    dst->reserved0 = src->action;
    if (src->action == DATA_ACTION) {
        dst->version = sizeof(sensors_event_t);
        dst->timestamp = src->timestamp;
        dst->sensor = src->sensor_type;
        dst->type = src->sensor_type;
        switch (src->sensor_type) {
        case SENSOR_TYPE_ACCELEROMETER:
            dst->acceleration.x = (float)src->word[0] / gain;
            dst->acceleration.y = (float)src->word[1] / gain;
            dst->acceleration.z = (float)src->word[2] / gain;
            dst->data[13] = (float)src->word[3] / gain;
            dst->data[14] = (float)src->word[4] / gain;
            dst->data[15] = (float)src->word[5] / gain;
            dst->acceleration.status = src->accurancy;
            break;
        case SENSOR_TYPE_MAGNETIC_FIELD:
            dst->magnetic.x = (float)src->word[0] / gain;
            dst->magnetic.y = (float)src->word[1] / gain;
            dst->magnetic.z = (float)src->word[2] / gain;
            dst->data[13] = (float)src->word[3] / gain;
            dst->data[14] = (float)src->word[4] / gain;
            dst->data[15] = (float)src->word[5] / gain;
            dst->magnetic.status = src->accurancy;
            break;
        case SENSOR_TYPE_GYROSCOPE:
            dst->gyro.x = (float)src->word[0] / gain;
            dst->gyro.y = (float)src->word[1] / gain;
            dst->gyro.z = (float)src->word[2] / gain;
            dst->data[13] = (float)src->word[3] / gain;
            dst->data[14] = (float)src->word[4] / gain;
            dst->data[15] = (float)src->word[5] / gain;
            dst->gyro.status = src->accurancy;
            break;
        case SENSOR_TYPE_ORIENTATION:
            dst->orientation.azimuth = (float)src->word[0] / gain;
            dst->orientation.pitch = (float)src->word[1] / gain;
            dst->orientation.roll = (float)src->word[2] / gain;
            dst->orientation.status = src->accurancy;
            break;
        case SENSOR_TYPE_ROTATION_VECTOR:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            break;
        case SENSOR_TYPE_GAME_ROTATION_VECTOR:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            break;
        case SENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            break;
        case SENSOR_TYPE_LINEAR_ACCELERATION:
            dst->acceleration.x = (float)src->word[0] / gain;
            dst->acceleration.y = (float)src->word[1] / gain;
            dst->acceleration.z = (float)src->word[2] / gain;
            dst->acceleration.status = src->accurancy;
            break;
        case SENSOR_TYPE_GRAVITY:
            dst->acceleration.x = (float)src->word[0] / gain;
            dst->acceleration.y = (float)src->word[1] / gain;
            dst->acceleration.z = (float)src->word[2] / gain;
            dst->acceleration.status = src->accurancy;
            break;
        case SENSOR_TYPE_ACCELEROMETER_UNCALIBRATED:
        case SENSOR_TYPE_MAGNETIC_FIELD_UNCALIBRATED:
        case SENSOR_TYPE_GYROSCOPE_UNCALIBRATED:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            dst->data[4] = (float)src->word[4] / gain;
            dst->data[5] = (float)src->word[5] / gain;
            break;
        case SENSOR_TYPE_GYRO_SECONDARY:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            break;
        case SENSOR_TYPE_LIGHT:
            dst->light = (float)src->word[0] / gain;
            break;
        case SENSOR_TYPE_PRESSURE:
            dst->pressure = (float)src->word[0] / gain;
            break;
        case SENSOR_TYPE_PROXIMITY:
            dst->distance = (float)src->word[0] / gain;
            ALOGI("distance = %f\n", dst->distance);
            break;
        case SENSOR_TYPE_STEP_COUNTER:
            dst->u64.step_counter = (float)src->word[0];
            break;
        /*
         * for wakeup sensor:
         * sensors_event_t.sensor = SENSOR_TYPE_XXX_WAKEUP
         * sensors_event_t.type = SENSOR_TYPE_XXX
         */
        case SENSOR_TYPE_STEP_DETECTOR_WAKEUP:
            /* restore type to SENSOR_TYPE_XXX */
            dst->type = src->sensor_type - WAKEUP_SENSOR_BASE;
            dst->data[0] = (float)src->word[0];
            dst->data[1] = (float)src->word[1];
            dst->data[2] = (float)src->word[2];
            dst->data[3] = (float)src->word[3];
            dst->data[4] = (float)src->word[4];
            dst->data[5] = (float)src->word[5];
            break;
        /*
         * for private sensor:
         * sensors_event_t.sensor = SENSOR_TYPE_XXX
         * sensors_event_t.type = SENSOR_TYPE_XXX + SENSOR_TYPE_DEVICE_PRIVATE_BASE
         */
        case SENSOR_TYPE_PEDOMETER:
        case SENSOR_TYPE_IN_POCKET:
        case SENSOR_TYPE_ACTIVITY:
        case SENSOR_TYPE_PDR:
        case SENSOR_TYPE_FREEFALL:
        case SENSOR_TYPE_FLAT:
        case SENSOR_TYPE_FACE_DOWN:
        case SENSOR_TYPE_SHAKE:
        case SENSOR_TYPE_BRINGTOSEE:
        case SENSOR_TYPE_ANSWER_CALL:
        case SENSOR_TYPE_GEOFENCE:
        case SENSOR_TYPE_FLOOR_COUNTER:
        case SENSOR_TYPE_EKG:
        case SENSOR_TYPE_PPG1:
        case SENSOR_TYPE_PPG2:
        case SENSOR_TYPE_RGBW:
        case SENSOR_TYPE_GYRO_TEMPERATURE:
        case SENSOR_TYPE_SAR:
            /* restore type to plus SENSOR_TYPE_DEVICE_PRIVATE_BASE */
            dst->type = src->sensor_type + SENSOR_TYPE_DEVICE_PRIVATE_BASE;
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            dst->data[4] = (float)src->word[4] / gain;
            dst->data[5] = (float)src->word[5] / gain;
            break;
        /*
         * follow sensor run in default branch
         * case SENSOR_TYPE_STATIONARY_DETECT:
         * case SENSOR_TYPE_MOTION_DETECT;
         * case SENSOR_TYPE_WAKE_GESTURE:
         * case SENSOR_TYPE_PICK_UP_GESTURE:
         * case SENSOR_TYPE_GLANCE_GESTURE:
         * case SENSOR_TYPE_DEVICE_ORIENTATION:
         * case SENSOR_TYPE_TILT_DETECTOR:
         * case SENSOR_TYPE_STEP_DETECTOR:
         * case SENSOR_TYPE_SIGNIFICANT_MOTION:
         */
        default:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            dst->data[4] = (float)src->word[4] / gain;
            dst->data[5] = (float)src->word[5] / gain;
            break;
        }
    } else if (src->action == FLUSH_ACTION) {
        dst->version = META_DATA_VERSION;
        dst->sensor = 0;
        dst->type = SENSOR_TYPE_META_DATA;
        dst->meta_data.what = META_DATA_FLUSH_COMPLETE;
        dst->meta_data.sensor = src->sensor_type;
        dst->timestamp = src->timestamp;
        ALOGI("[%d] flush complete\n", dst->meta_data.sensor);
    } else if (src->action == RAW_ACTION) {
        dst->version = sizeof(sensors_event_t);
        dst->timestamp = src->timestamp;
        dst->sensor = src->sensor_type;
        dst->type = src->sensor_type;
        switch (src->sensor_type) {
        case SENSOR_TYPE_ACCELEROMETER:
            dst->acceleration.x = (float)src->word[0] / gain;
            dst->acceleration.y = (float)src->word[1] / gain;
            dst->acceleration.z = (float)src->word[2] / gain;
            break;
        case SENSOR_TYPE_MAGNETIC_FIELD:
            dst->magnetic.x = (float)src->word[0] / gain;
            dst->magnetic.y = (float)src->word[1] / gain;
            dst->magnetic.z = (float)src->word[2] / gain;
            break;
        case SENSOR_TYPE_GYROSCOPE:
            dst->gyro.x = (float)src->word[0] / gain;
            dst->gyro.y = (float)src->word[1] / gain;
            dst->gyro.z = (float)src->word[2] / gain;
            break;
        case SENSOR_TYPE_PRESSURE:
            dst->pressure = (float)src->word[0] / gain;
            break;
        default:
            dst->data[0] = (float)src->word[0] / gain;
            dst->data[1] = (float)src->word[1] / gain;
            dst->data[2] = (float)src->word[2] / gain;
            dst->data[3] = (float)src->word[3] / gain;
            dst->data[4] = (float)src->word[4] / gain;
            dst->data[5] = (float)src->word[5] / gain;
            break;
        }
    } else if (src->action == CALI_ACTION) {
        dst->version = sizeof(sensors_event_t);
        dst->timestamp = src->timestamp;
        dst->sensor = src->sensor_type;
        dst->type = src->sensor_type;
        switch (src->sensor_type) {
            case SENSOR_TYPE_ACCELEROMETER:
                dst->acceleration.x = (float)src->word[0];
                dst->acceleration.y = (float)src->word[1];
                dst->acceleration.z = (float)src->word[2];
                dst->acceleration.status = src->accurancy;
                break;
            case SENSOR_TYPE_GYROSCOPE:
                dst->gyro.x = (float)src->word[0];
                dst->gyro.y = (float)src->word[1];
                dst->gyro.z = (float)src->word[2];
                dst->gyro.status = src->accurancy;
                break;
            default:
                dst->data[0] = (float)src->word[0];
                dst->data[1] = (float)src->word[1];
                dst->data[2] = (float)src->word[2];
                dst->data[3] = (float)src->word[3];
                dst->data[4] = (float)src->word[4];
                dst->data[5] = (float)src->word[5];
        }
    } else {
        dst->version = sizeof(sensors_event_t);
        dst->timestamp = src->timestamp;
        dst->sensor = src->sensor_type;
        dst->type = src->sensor_type;
        dst->data[0] = (float)src->word[0];
        dst->data[1] = (float)src->word[1];
        dst->data[2] = (float)src->word[2];
        dst->data[3] = (float)src->word[3];
        dst->data[4] = (float)src->word[4];
        dst->data[5] = (float)src->word[5];
    }
    return true;
}

int HfLooper::eventLooper(std::function<void(sensors_event_t const *)> callback) {
    int err = -1, count = 0;
    ssize_t len = 0;
    hf_manager_event *buffer;
    sensors_event_t event;

    if ((err = initCheck()) < 0)
        return err;

    err = TEMP_FAILURE_RETRY(poll(mPollFds, mNumPollFds, -1));

    if (mPollFds[0].revents & POLLIN) {
        len = mPollBufferSize * sizeof(hf_manager_event);
        memset(pollBuffer.get(), 0, len);
        len = TEMP_FAILURE_RETRY(read(mFd, pollBuffer.get(), len));
        if (len < 0) {
            ALOGE("eventLooper read failed err=%zd errno=%d\n", len, errno);
            len = 0;
        }
        if (len % sizeof(hf_manager_event)) {
            ALOGE("eventLooper len failed err=%zu errno=%d\n", len, errno);
            len = 0;
        }
        count = len / sizeof(hf_manager_event);
        buffer = pollBuffer.get();
        for (ssize_t i = 0; i < count; ++i) {
            eventConvertAll(&event, &buffer[i]);
            callback(&event);
        }
    }
    return count;
}

int HfLooper::eventLooperSignal(sensors_event_t *data, int count) {
    int err = -1, size = 0;
    ssize_t len = 0;
    hf_manager_event *buffer;

    if ((err = initCheck()) < 0)
        return err;

    err = poll(mPollFds, mNumPollFds, -1);
    if (err < 0)
        return err;

    if (mPollFds[0].revents & POLLIN) {
        /* reset all bufferm alloced */
        memset(pollBuffer.get(), 0, mPollBufferSize * sizeof(hf_manager_event));

        size = (count > mPollBufferSize) ? mPollBufferSize : count;
        len = size * sizeof(hf_manager_event);

        len = TEMP_FAILURE_RETRY(read(mFd, pollBuffer.get(), len));
        if (len < 0) {
            ALOGE("eventLooper read failed err=%zd errno=%d\n", len, errno);
            len = 0;
        }
        if (len % sizeof(hf_manager_event)) {
            ALOGE("eventLooper len failed err=%zu errno=%d\n", len, errno);
            len = 0;
        }
        size = len / sizeof(hf_manager_event);
        buffer = pollBuffer.get();
        for (int i = 0; i < size; ++i) {
            eventConvertAll(&data[i], &buffer[i]);
        }
    }
    return size;
}

int HfLooper::eventLooper(sensors_event_t *data, int count, int timeout) {
    int err = -1, size = 0;
    ssize_t len = 0;
    hf_manager_event *buffer;

    if ((err = initCheck()) < 0)
        return err;

    err = TEMP_FAILURE_RETRY(poll(mPollFds, mNumPollFds, timeout));

    if (mPollFds[0].revents & POLLIN) {
        /* reset all bufferm alloced */
        memset(pollBuffer.get(), 0, mPollBufferSize * sizeof(hf_manager_event));

        size = (count > mPollBufferSize) ? mPollBufferSize : count;
        len = size * sizeof(hf_manager_event);

        len = TEMP_FAILURE_RETRY(read(mFd, pollBuffer.get(), len));
        if (len < 0) {
            ALOGE("eventLooper read failed err=%zd errno=%d\n", len, errno);
            len = 0;
        }
        if (len % sizeof(hf_manager_event)) {
            ALOGE("eventLooper len failed err=%zu errno=%d\n", len, errno);
            len = 0;
        }
        size = len / sizeof(hf_manager_event);
        buffer = pollBuffer.get();
        for (int i = 0; i < size; ++i) {
            eventConvertAll(&data[i], &buffer[i]);
        }
    }
    return size;
}

int HfLooper::eventLooper(sensors_event_t *data, int count) {
    return eventLooper(data, count, -1);
}

int HfLooper::eventRead(sensors_event_t *data, int count) {
    int size = 0, data_flush_count = 0;
    ssize_t len = 0;
    hf_manager_event *buffer;

    /* reset all bufferm alloced */
    memset(pollBuffer.get(), 0, mPollBufferSize * sizeof(hf_manager_event));

    size = (count > mPollBufferSize) ? mPollBufferSize : count;
    len = size * sizeof(hf_manager_event);

    len = TEMP_FAILURE_RETRY(read(mFd, pollBuffer.get(), len));
    if (len < 0) {
        ALOGE("eventRead read failed err=%zd errno=%d\n", len, errno);
        len = 0;
    }
    if (len % sizeof(hf_manager_event)) {
        ALOGE("eventRead len failed err=%zu errno=%d\n", len, errno);
        len = 0;
    }
    size = len / sizeof(hf_manager_event);
    buffer = pollBuffer.get();
    for (int i = 0; i < size; ++i) {
        if (eventConvertDataFlush(&data[i], &buffer[i]))
            data_flush_count++;
    }
    return data_flush_count;
}

void HfLooper::setGain(int sensor, uint32_t gain) {
    if (sensor < SENSOR_TYPE_SENSOR_MAX && gain)
        info[sensor].gain = gain;
}

uint32_t HfLooper::getGain(int sensor) {
    if (sensor < SENSOR_TYPE_SENSOR_MAX)
        return info[sensor].gain;
    return 1;
}

void HfLooper::getSensorInfo(int fd, bool hasManager) {
    int err = -1;
    ioctl_packet packet;

    for (int sensor = 0; sensor < SENSOR_TYPE_SENSOR_MAX; ++sensor) {
        memset(&packet, 0, sizeof(packet));
        if (hasManager) {
            packet.sensor_type = sensor;
            err = TEMP_FAILURE_RETRY(ioctl(fd,
                HF_MANAGER_REQUEST_SENSOR_INFO, &packet));
        } else {
            err = -1;
        }
        if (err < 0) {
            info[sensor].sensor_type = sensor;
            info[sensor].gain = 1;
        } else {
            memcpy(&info[sensor], packet.byte, sizeof(info[sensor]));
        }
    }
}

