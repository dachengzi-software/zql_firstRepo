/*
 * Copyright Statement:
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * Copyright  (C) [2019]  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#ifndef _HF_SENSOR_TYPE_H_
#define _HF_SENSOR_TYPE_H_

#define SENSOR_STRING_TYPE_PEDOMETER        "android.sensor.pedometer"
#define SENSOR_STRING_TYPE_IN_POCKET        "android.sensor.in_pocket"
#define SENSOR_STRING_TYPE_ACTIVITY         "android.sensor.activity"
#define SENSOR_STRING_TYPE_PDR              "android.sensor.pdr"
#define SENSOR_STRING_TYPE_FREEFALL         "android.sensor.freefall"
#define SENSOR_STRING_TYPE_FLAT             "android.sensor.flat"
#define SENSOR_STRING_TYPE_FACE_DOWN        "android.sensor.face_down"
#define SENSOR_STRING_TYPE_SHAKE            "android.sensor.shake"
#define SENSOR_STRING_TYPE_BRINGTOSEE       "android.sensor.bring_to_see"
#define SENSOR_STRING_TYPE_ANSWERCALL       "android.sensor.answer_call"
#define SENSOR_STRING_TYPE_FLOOR_COUNTER    "android.sensor.floor_count"
#define SENSOR_STRING_TYPE_EKG              "android.sensor.ekg"
#define SENSOR_STRING_TYPE_PPG1             "android.sensor.ppg1"
#define SENSOR_STRING_TYPE_PPG2             "android.sensor.ppg2"
#define SENSOR_STRING_TYPE_RGBW             "android.sensor.rgbw"
#define SENSOR_STRING_TYPE_GYRO_TEMPERATURE "android.sensor.gyro_temperature"
#define SENSOR_STRING_TYPE_SAR              "android.sensor.sar"
#define SENSOR_STRING_TYPE_OIS              "android.sensor.ois"

#define WAKEUP_SENSOR_BASE 100

enum {
    /* follow mtk add sensor type */
    SENSOR_TYPE_PEDOMETER = 55,
    SENSOR_TYPE_IN_POCKET,
    SENSOR_TYPE_ACTIVITY,
    SENSOR_TYPE_PDR,
    SENSOR_TYPE_FREEFALL,
    SENSOR_TYPE_FLAT,
    SENSOR_TYPE_FACE_DOWN,
    SENSOR_TYPE_SHAKE,
    SENSOR_TYPE_BRINGTOSEE,
    SENSOR_TYPE_ANSWER_CALL,
    SENSOR_TYPE_GEOFENCE,
    SENSOR_TYPE_FLOOR_COUNTER,
    SENSOR_TYPE_EKG,
    SENSOR_TYPE_PPG1,
    SENSOR_TYPE_PPG2,
    SENSOR_TYPE_RGBW,
    SENSOR_TYPE_GYRO_TEMPERATURE,
    SENSOR_TYPE_SAR,
    SENSOR_TYPE_OIS,
    SENSOR_TYPE_GYRO_SECONDARY,
    SENSOR_TYPE_SENSOR_MAX,

    SENSOR_TYPE_STEP_DETECTOR_WAKEUP = SENSOR_TYPE_STEP_DETECTOR + WAKEUP_SENSOR_BASE,
};

#if SENSOR_TYPE_SENSOR_MAX >= WAKEUP_SENSOR_BASE
#error sensor type over the upper limit
#endif

enum {
    SENSOR_ACCURANCY_UNRELIALE,
    SENSOR_ACCURANCY_LOW,
    SENSOR_ACCURANCY_MEDIUM,
    SENSOR_ACCURANCY_HIGH,
};

#endif
