/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include <V2_0/SubHal.h>
#include <hardware/sensors.h>

#include <vector>
#include <mutex>
#include <atomic>
#include <memory>
#include <thread>

namespace android {
namespace hardware {
namespace sensors {
namespace V2_0 {
namespace subhal {
namespace implementation {

using ::android::hardware::sensors::V1_0::OperationMode;
using ::android::hardware::sensors::V1_0::Result;
using ::android::hardware::sensors::V2_0::implementation::IHalProxyCallback;

class Sensors : public ISensorsSubHal {
    using Event = ::android::hardware::sensors::V1_0::Event;
    using RateLevel = ::android::hardware::sensors::V1_0::RateLevel;
    using SharedMemInfo = ::android::hardware::sensors::V1_0::SharedMemInfo;
    using SensorInfo = ::android::hardware::sensors::V1_0::SensorInfo;

public:
    Sensors();

    // Methods from ::android::hardware::sensors::V2_0::ISensors follow.
    virtual Return<void> getSensorsList(getSensorsList_cb _hidl_cb) override;

    virtual Return<Result> setOperationMode(OperationMode mode) override;

    OperationMode getOperationMode() const { return mCurrentOperationMode; }

    Return<Result> activate(int32_t sensorHandle, bool enabled) override;

    Return<Result> batch(int32_t sensorHandle, int64_t samplingPeriodNs,
                         int64_t maxReportLatencyNs) override;

    Return<Result> flush(int32_t sensorHandle) override;

    Return<Result> injectSensorData(const Event& event) override;

    Return<void> registerDirectChannel(const SharedMemInfo& mem,
                                       registerDirectChannel_cb _hidl_cb) override;

    Return<Result> unregisterDirectChannel(int32_t channelHandle) override;

    Return<void> configDirectReport(int32_t sensorHandle, int32_t channelHandle, RateLevel rate,
                                    configDirectReport_cb _hidl_cb) override;

    Return<void> debug(const hidl_handle& fd, const hidl_vec<hidl_string>& args) override;

    // Methods from ::android::hardware::sensors::V2_0::implementation::ISensorsSubHal follow.
    const std::string getName() override {
        return "mediatek-shubhal";
    }

    Return<Result> initialize(const sp<IHalProxyCallback>& halProxyCallback) override;

private:
    static constexpr int32_t kPollMaxBufferSize = 128;

    OperationMode mCurrentOperationMode = OperationMode::NORMAL;

    std::map<int32_t, SensorInfo> mSensors;

    sp<IHalProxyCallback> mCallback;

    sensors_module_t *mSensorModule;

    sensors_poll_device_1_t *mSensorDevice;

    std::atomic_bool mRunThreadEnable;

    std::thread mRunThread;

    int getHalDeviceVersion() const;

    bool isWakeUpSensor(int32_t handle);

    bool convertFromSensorEvents(
            size_t count, const sensors_event_t *src, std::vector<Event> *dst);

    void poll();

    void postEvents(const std::vector<Event>& events, bool wakeup);
};

}  // namespace implementation
}  // namespace subhal
}  // namespace V2_0
}  // namespace sensors
}  // namespace hardware
}  // namespace android

using ::android::hardware::sensors::V2_0::implementation::ISensorsSubHal;

/**
 * Function that must be exported so the HalProxy class can invoke it on the sub-HAL dynamic
 * library. This function will only be invoked once at initialization time.
 *
 * NOTE: The supported sensors HAL version must match SUB_HAL_2_0_VERSION exactly or the HalProxy
 *     will fail to initialize.
 *
 * @param uint32_t when this function returns, this parameter must contain the HAL version that
 *     this sub-HAL supports. To support this version of multi-HAL, this must be set to
 *     SUB_HAL_2_0_VERSION.
 * @return A statically allocated, valid ISensorsSubHal implementation.
 */
__attribute__((visibility("default"))) extern "C" ISensorsSubHal* sensorsHalGetSubHal(
        uint32_t* version);
