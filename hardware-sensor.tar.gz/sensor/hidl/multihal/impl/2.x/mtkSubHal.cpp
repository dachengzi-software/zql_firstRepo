/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mtkSubHal.h"

#include <android/hardware/sensors/2.0/types.h>

#include <sensors/convert.h>

#include <android-base/logging.h>

#include <log/log.h>

#undef LOG_TAG
#define LOG_TAG "mtkSubHal"

#define DEBUG_CONNECTIONS false
#define UNUSED(x) (void)(x)

ISensorsSubHal* sensorsHalGetSubHal(uint32_t* version) {
    static ::android::hardware::sensors::V2_0::subhal::implementation::Sensors subHal;
    *version = SUB_HAL_2_0_VERSION;
    return &subHal;
}

namespace android {
namespace hardware {
namespace sensors {
namespace V2_0 {
namespace subhal {
namespace implementation {

using namespace android::hardware::sensors::V1_0::implementation;

using ::android::hardware::Void;
using ::android::hardware::sensors::V1_0::Event;
using ::android::hardware::sensors::V1_0::OperationMode;
using ::android::hardware::sensors::V1_0::RateLevel;
using ::android::hardware::sensors::V1_0::Result;
using ::android::hardware::sensors::V1_0::SharedMemInfo;
using ::android::hardware::sensors::V1_0::SensorInfo;
using ::android::hardware::sensors::V1_0::SensorFlagBits;
using ::android::hardware::sensors::V2_0::SensorTimeout;
using ::android::hardware::sensors::V2_0::WakeLockQueueFlagBits;
using ::android::hardware::sensors::V2_0::implementation::ScopedWakelock;

static Result ResultFromStatus(status_t err) {
    switch (err) {
        case OK:
            return Result::OK;
        case PERMISSION_DENIED:
            return Result::PERMISSION_DENIED;
        case NO_MEMORY:
            return Result::NO_MEMORY;
        case BAD_VALUE:
            return Result::BAD_VALUE;
        default:
            return Result::INVALID_OPERATION;
    }
}

Sensors::Sensors()
    : mCallback(nullptr),
      mSensorModule(nullptr),
      mSensorDevice(nullptr),
      mRunThreadEnable(false) {
    status_t err = OK;
    err = hw_get_module(SENSORS_HARDWARE_MODULE_ID,
        (hw_module_t const **)&mSensorModule);
    if (mSensorModule == NULL) {
        err = UNKNOWN_ERROR;
    }

    if (err != OK) {
        ALOGE("Couldn't load %s module (%s)",
            SENSORS_HARDWARE_MODULE_ID, strerror(-err));
        return;
    }

    err = sensors_open_1(&mSensorModule->common, &mSensorDevice);

    if (err != OK) {
        ALOGE("Couldn't open device for module %s (%s)",
            SENSORS_HARDWARE_MODULE_ID, strerror(-err));
        return;
    }

    // Require all the old HAL APIs to be present except for injection, which
    // is considered optional.
    CHECK_GE(getHalDeviceVersion(), SENSORS_DEVICE_API_VERSION_1_3);

    if (getHalDeviceVersion() == SENSORS_DEVICE_API_VERSION_1_4) {
        if (mSensorDevice->inject_sensor_data == nullptr) {
            ALOGE("HAL specifies version 1.4, but does not implement inject_sensor_data()");
        }
        if (mSensorModule->set_operation_mode == nullptr) {
            ALOGE("HAL specifies version 1.4, but does not implement set_operation_mode()");
        }
    }

    mRunThreadEnable = true;
    mRunThread = std::thread([this]() {
        this->poll();
    });
    ALOGI("HIDL mediatek subhal 2.x load sensor module success.");
}

Return<void> Sensors::getSensorsList(getSensorsList_cb _hidl_cb) {
    sensor_t const *list;
    size_t count = mSensorModule->get_sensors_list(mSensorModule, &list);

    std::vector<SensorInfo> out;
    out.resize(count);

    for (size_t i = 0; i < count; ++i) {
        const sensor_t *src = &list[i];
        SensorInfo *dst = &out[i];

        convertFromSensor(*src, dst);
        mSensors.insert(std::make_pair(dst->sensorHandle, *dst));
    }

    _hidl_cb(out);

    return Void();
}

Return<Result> Sensors::setOperationMode(OperationMode mode) {
    mCurrentOperationMode = mode;
    if (getHalDeviceVersion() < SENSORS_DEVICE_API_VERSION_1_4
            || mSensorModule->set_operation_mode == nullptr) {
        return Result::INVALID_OPERATION;
    }
    return ResultFromStatus(mSensorModule->set_operation_mode((uint32_t)mode));
}

Return<Result> Sensors::activate(
        int32_t sensor_handle, bool enabled) {
    ALOGI_IF(DEBUG_CONNECTIONS, "activate handle(%d) enable(%d).", sensor_handle, enabled);
    return ResultFromStatus(
            mSensorDevice->activate(
                reinterpret_cast<sensors_poll_device_t *>(mSensorDevice),
                sensor_handle,
                enabled));
}

Return<Result> Sensors::batch(
        int32_t sensor_handle,
        int64_t sampling_period_ns,
        int64_t max_report_latency_ns) {
    ALOGI_IF(DEBUG_CONNECTIONS, "batch handle(%d)...", sensor_handle);
    return ResultFromStatus(
            mSensorDevice->batch(
                mSensorDevice,
                sensor_handle,
                0, /*flags*/
                sampling_period_ns,
                max_report_latency_ns));
}

Return<Result> Sensors::flush(int32_t sensor_handle) {
    ALOGI_IF(DEBUG_CONNECTIONS, "flush handle(%d)...", sensor_handle);
    return ResultFromStatus(mSensorDevice->flush(mSensorDevice, sensor_handle));
}

Return<Result> Sensors::injectSensorData(const Event& event) {
    if (getHalDeviceVersion() < SENSORS_DEVICE_API_VERSION_1_4
            || mSensorDevice->inject_sensor_data == nullptr) {
        return Result::INVALID_OPERATION;
    }

    sensors_event_t out;
    convertToSensorEvent(event, &out);

    return ResultFromStatus(
            mSensorDevice->inject_sensor_data(mSensorDevice, &out));
}

Return<void> Sensors::registerDirectChannel(
        const SharedMemInfo& mem, registerDirectChannel_cb _hidl_cb) {
    if (mSensorDevice->register_direct_channel == nullptr
            || mSensorDevice->config_direct_report == nullptr) {
        // HAL does not support
        _hidl_cb(Result::INVALID_OPERATION, -1);
        return Void();
    }

    sensors_direct_mem_t m;
    if (!convertFromSharedMemInfo(mem, &m)) {
      _hidl_cb(Result::BAD_VALUE, -1);
      return Void();
    }

    int err = mSensorDevice->register_direct_channel(mSensorDevice, &m, -1);

    if (err < 0) {
        _hidl_cb(ResultFromStatus(err), -1);
    } else {
        int32_t channelHandle = static_cast<int32_t>(err);
        _hidl_cb(Result::OK, channelHandle);
    }
    return Void();
}

Return<Result> Sensors::unregisterDirectChannel(int32_t channelHandle) {
    if (mSensorDevice->register_direct_channel == nullptr
            || mSensorDevice->config_direct_report == nullptr) {
        // HAL does not support
        return Result::INVALID_OPERATION;
    }

    mSensorDevice->register_direct_channel(mSensorDevice, nullptr, channelHandle);

    return Result::OK;
}

Return<void> Sensors::configDirectReport(
        int32_t sensorHandle, int32_t channelHandle, RateLevel rate,
        configDirectReport_cb _hidl_cb) {
    if (mSensorDevice->register_direct_channel == nullptr
            || mSensorDevice->config_direct_report == nullptr) {
        // HAL does not support
        _hidl_cb(Result::INVALID_OPERATION, -1);
        return Void();
    }

    sensors_direct_cfg_t cfg = {
        .rate_level = convertFromRateLevel(rate)
    };
    if (cfg.rate_level < 0) {
        _hidl_cb(Result::BAD_VALUE, -1);
        return Void();
    }

    int err = mSensorDevice->config_direct_report(mSensorDevice,
            sensorHandle, channelHandle, &cfg);

    if (rate == RateLevel::STOP) {
        _hidl_cb(ResultFromStatus(err), -1);
    } else {
        _hidl_cb(err > 0 ? Result::OK : ResultFromStatus(err), err);
    }
    return Void();
}

Return<void> Sensors::debug(const hidl_handle& fd, const hidl_vec<hidl_string>& args) {
    if (fd.getNativeHandle() == nullptr || fd->numFds < 1) {
        ALOGE("%s: missing fd for writing", __FUNCTION__);
        return Void();
    }

    FILE* out = fdopen(dup(fd->data[0]), "w");

    if (args.size() != 0) {
        fprintf(out,
                "Note: sub-HAL %s currently does not support args. Input arguments are "
                "ignored.\n",
                getName().c_str());
    }

    std::ostringstream stream;
    stream << "Available sensors:" << std::endl;
    for (auto sensor : mSensors) {
        SensorInfo info = sensor.second;
        stream << "Name: " << info.name << std::endl;
        stream << "Min delay: " << info.minDelay << std::endl;
        stream << "Flags: " << info.flags << std::endl;
    }
    stream << std::endl;

    fprintf(out, "%s", stream.str().c_str());

    fclose(out);
    return Return<void>();
}

Return<Result> Sensors::initialize(const sp<IHalProxyCallback>& halProxyCallback) {
    mCallback = halProxyCallback;
    setOperationMode(OperationMode::NORMAL);
    return Result::OK;
}

int Sensors::getHalDeviceVersion() const {
    if (!mSensorDevice) {
        return -1;
    }

    return mSensorDevice->common.version;
}

bool Sensors::isWakeUpSensor(int32_t handle) {
    auto i = mSensors.find(handle);
    if (i != mSensors.end()) {
        return i->second.flags & static_cast<uint32_t>(SensorFlagBits::WAKE_UP);
    }
    return false;
}

bool Sensors::convertFromSensorEvents(
        size_t count,
        const sensors_event_t *srcArray,
        std::vector<Event> *dstVec) {
    bool wakeup = false;

    for (size_t i = 0; i < count; ++i) {
        const sensors_event_t &src = srcArray[i];
        Event *dst = &(*dstVec)[i];

        convertFromSensorEvent(src, dst);
        wakeup |= isWakeUpSensor(dst->sensorHandle);
    }
    return wakeup;
}

void Sensors::poll() {
    int err = 0;
    std::unique_ptr<sensors_event_t[]> data;
    int bufferSize = kPollMaxBufferSize;
    std::vector<Event> events;
    bool wakeup = false;

    data.reset(new sensors_event_t[bufferSize]);

    while (mRunThreadEnable.load()) {
        memset(data.get(), 0, bufferSize * sizeof(sensors_event_t));
        err = mSensorDevice->poll(
                reinterpret_cast<sensors_poll_device_t *>(mSensorDevice),
                data.get(), bufferSize);

        if (err < 0)
            continue;
        const size_t count = (size_t)err;
        events.resize(count);
        wakeup = convertFromSensorEvents(count, data.get(), &events);
        postEvents(events, wakeup);
    }
}

void Sensors::postEvents(const std::vector<Event>& events, bool wakeup) {
    ScopedWakelock wakelock = mCallback->createScopedWakelock(wakeup);
    mCallback->postEvents(events, std::move(wakelock));
}

}  // namespace implementation
}  // namespace subhal
}  // namespace V2_0
}  // namespace sensors
}  // namespace hardware
}  // namespace android
